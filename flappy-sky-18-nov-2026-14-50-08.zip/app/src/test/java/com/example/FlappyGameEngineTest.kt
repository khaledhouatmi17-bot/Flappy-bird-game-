package com.example

import com.example.game.FlappyGameEngine
import com.example.game.GROUND_HEIGHT
import com.example.game.WORLD_H
import com.example.model.GamePhase
import com.example.model.MedalTier
import com.example.model.stageLevelForScore
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class FlappyGameEngineTest {

    @Test
    fun stageProgressionMapsEveryFivePointsThroughStageSix() {
        assertEquals(1, stageLevelForScore(0))
        assertEquals(1, stageLevelForScore(4))
        assertEquals(2, stageLevelForScore(5))
        assertEquals(3, stageLevelForScore(10))
        assertEquals(4, stageLevelForScore(15))
        assertEquals(5, stageLevelForScore(20))
        assertEquals(6, stageLevelForScore(25))
        assertEquals(6, stageLevelForScore(99))
    }

    @Test
    fun medalTierScalesWithScore() {
        assertEquals(MedalTier.NONE, MedalTier.fromScore(3))
        assertEquals(MedalTier.BRONZE, MedalTier.fromScore(5))
        assertEquals(MedalTier.SILVER, MedalTier.fromScore(10))
        assertEquals(MedalTier.GOLD, MedalTier.fromScore(25))
        assertEquals(MedalTier.PLATINUM, MedalTier.fromScore(40))
    }

    @Test
    fun tapTransitionsReadyToPlayingAndGroundCollisionEndsFlight() {
        var finishedCalled = false
        var flapCount = 0
        val engine = FlappyGameEngine(
            onFlapSfx = { flapCount++ },
            onScoreSfx = {},
            onCoinSfx = {},
            onHitSfx = {},
            onStageUpSfx = {},
            onRecordCelebrationSfx = {},
            onHapticImpact = {},
            onFlightFinished = { _, _, _, _ -> finishedCalled = true }
        )

        engine.prepareReady()
        assertEquals(GamePhase.READY, engine.phase)

        engine.onTapAction()
        assertEquals(GamePhase.PLAYING, engine.phase)
        assertEquals(1, flapCount)
        assertTrue(engine.birdVy < 0f)

        // Simulate falling until ground collision
        repeat(120) {
            if (engine.phase == GamePhase.PLAYING) {
                engine.step(0.03f)
            }
        }

        assertEquals(GamePhase.GAME_OVER, engine.phase)
        assertTrue(finishedCalled)
        assertTrue(engine.birdY <= WORLD_H - GROUND_HEIGHT)
    }
}
