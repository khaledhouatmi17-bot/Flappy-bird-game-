package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PlayerRepository
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class LocalPlayerRepositoryTest {

    @Test
    fun recordsHighScoreAndCoinsLocally() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repo = PlayerRepository(context)

        repo.recordCompletedFlight(
            score = 18,
            stageReached = 4,
            coinsEarned = 7,
            skinId = "classic"
        ).getOrThrow()

        repo.recordCompletedFlight(
            score = 9,
            stageReached = 2,
            coinsEarned = 3,
            skinId = "classic"
        ).getOrThrow()

        val profile = repo.profileFlow.first()
        assertEquals(18, profile.bestScore)
        assertEquals(4, profile.highestStage)
        assertEquals(10, profile.totalCoins)

        val unlocked = repo.unlockOrEquipSkin("crimson").getOrThrow()
        assertTrue(unlocked)
        val afterUnlock = repo.profileFlow.first()
        assertEquals("crimson", afterUnlock.selectedSkin)
        assertEquals(5, afterUnlock.totalCoins)
        assertTrue("crimson" in afterUnlock.unlockedSkins)
    }
}
