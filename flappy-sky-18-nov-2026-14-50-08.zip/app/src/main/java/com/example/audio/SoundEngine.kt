package com.example.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.pow
import kotlin.math.sin

class SoundEngine {
    private val sampleRate = 22050
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    @Volatile
    var soundEnabled: Boolean = true

    @Volatile
    var musicEnabled: Boolean = true
        set(value) {
            field = value
            if (!value) stopMusic()
        }

    private var musicJob: Job? = null
    private var noteIndex = 0

    private val flapSamples: ShortArray by lazy { synthesizeFlap() }
    private val scoreSamples: ShortArray by lazy { synthesizeScore() }
    private val coinSamples: ShortArray by lazy { synthesizeCoin() }
    private val hitSamples: ShortArray by lazy { synthesizeHit() }
    private val medalSamples: ShortArray by lazy { synthesizeMedal() }

    private val melodyFreqs = doubleArrayOf(
        329.63, 392.00, 440.00, 523.25,
        440.00, 392.00, 329.63, 293.66,
        329.63, 329.63, 392.00, 440.00,
        392.00, 329.63, 293.66, 261.63
    )

    fun playFlap() {
        if (!soundEnabled) return
        playBufferAsync(flapSamples)
    }

    fun playScore() {
        if (!soundEnabled) return
        playBufferAsync(scoreSamples)
    }

    fun playCoin() {
        if (!soundEnabled) return
        playBufferAsync(coinSamples)
    }

    fun playHit() {
        if (!soundEnabled) return
        playBufferAsync(hitSamples)
    }

    fun playMedal() {
        if (!soundEnabled) return
        playBufferAsync(medalSamples)
    }

    fun startMusic() {
        if (!musicEnabled || musicJob?.isActive == true) return
        musicJob = scope.launch {
            while (isActive && musicEnabled) {
                val freq = melodyFreqs[noteIndex % melodyFreqs.size]
                noteIndex++
                val note = synthesizeTone(
                    startFreq = freq,
                    endFreq = freq,
                    durationSec = 0.18,
                    amplitude = 0.055,
                    waveform = Waveform.SINE
                )
                playBufferBlocking(note)
                delay(40L)
            }
        }
    }

    fun stopMusic() {
        musicJob?.cancel()
        musicJob = null
    }

    fun release() {
        stopMusic()
        scope.cancel()
    }

    private fun playBufferAsync(samples: ShortArray) {
        scope.launch {
            playBufferBlocking(samples)
        }
    }

    private fun playBufferBlocking(samples: ShortArray) {
        var track: AudioTrack? = null
        try {
            val byteSize = samples.size * 2
            val minBuf = AudioTrack.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_OUT_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            val bufferSize = maxOf(minBuf, byteSize)
            track = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(sampleRate)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                        .build()
                )
                .setTransferMode(AudioTrack.MODE_STATIC)
                .setBufferSizeInBytes(bufferSize)
                .build()

            track.write(samples, 0, samples.size)
            track.play()
            val durationMs = (samples.size * 1000L) / sampleRate + 25L
            Thread.sleep(durationMs)
        } catch (_: Throwable) {
            // Audio device may be unavailable in headless tests; ignore safely.
        } finally {
            try {
                track?.stop()
                track?.release()
            } catch (_: Throwable) {
            }
        }
    }

    private enum class Waveform { SINE, TRIANGLE, SQUARE, SAWTOOTH }

    private fun synthesizeTone(
        startFreq: Double,
        endFreq: Double,
        durationSec: Double,
        amplitude: Double,
        waveform: Waveform,
        exponential: Boolean = false
    ): ShortArray {
        val count = (sampleRate * durationSec).toInt().coerceAtLeast(1)
        val out = ShortArray(count)
        var phase = 0.0
        for (i in 0 until count) {
            val t = i.toDouble() / count
            val freq = if (exponential && startFreq > 0 && endFreq > 0) {
                startFreq * (endFreq / startFreq).pow(t)
            } else {
                startFreq + (endFreq - startFreq) * t
            }
            phase += (2.0 * PI * freq) / sampleRate
            val env = (1.0 - t) * (if (t < 0.06) t / 0.06 else 1.0)
            val raw = when (waveform) {
                Waveform.SINE -> sin(phase)
                Waveform.TRIANGLE -> {
                    val norm = (phase / (2.0 * PI)) % 1.0
                    if (norm < 0.25) 4.0 * norm
                    else if (norm < 0.75) 2.0 - 4.0 * norm
                    else 4.0 * norm - 4.0
                }
                Waveform.SQUARE -> if (sin(phase) >= 0) 0.7 else -0.7
                Waveform.SAWTOOTH -> 2.0 * ((phase / (2.0 * PI)) % 1.0) - 1.0
            }
            val sample = (raw * amplitude * env * Short.MAX_VALUE)
                .toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
            out[i] = sample.toShort()
        }
        return out
    }

    private fun synthesizeFlap(): ShortArray {
        val main = synthesizeTone(320.0, 680.0, 0.12, 0.28, Waveform.SINE, exponential = true)
        val air = synthesizeTone(760.0, 420.0, 0.10, 0.07, Waveform.TRIANGLE, exponential = true)
        return mix(main, air)
    }

    private fun synthesizeScore(): ShortArray {
        val first = synthesizeTone(587.33, 587.33, 0.08, 0.24, Waveform.TRIANGLE)
        val second = synthesizeTone(880.00, 880.00, 0.17, 0.24, Waveform.TRIANGLE)
        return first + second
    }

    private fun synthesizeCoin(): ShortArray {
        val first = synthesizeTone(987.77, 987.77, 0.07, 0.17, Waveform.SQUARE)
        val second = synthesizeTone(1318.51, 1318.51, 0.15, 0.17, Waveform.SQUARE)
        return first + second
    }

    private fun synthesizeHit(): ShortArray {
        val count = (sampleRate * 0.28).toInt()
        val out = ShortArray(count)
        var phase = 0.0
        for (i in 0 until count) {
            val t = i.toDouble() / count
            val freq = 240.0 + (60.0 - 240.0) * t
            phase += (2.0 * PI * freq) / sampleRate
            val env = exp(-t * 3.5)
            val saw = 2.0 * ((phase / (2.0 * PI)) % 1.0) - 1.0
            out[i] = (saw * 0.34 * env * Short.MAX_VALUE)
                .toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                .toShort()
        }
        return out
    }

    private fun synthesizeMedal(): ShortArray {
        val notes = doubleArrayOf(523.25, 659.25, 783.99, 1046.50)
        val noteLen = (sampleRate * 0.15).toInt()
        val step = (sampleRate * 0.08).toInt()
        val total = step * (notes.size - 1) + noteLen
        val out = ShortArray(total)
        notes.forEachIndexed { idx, freq ->
            val tone = synthesizeTone(freq, freq, 0.15, 0.20, Waveform.TRIANGLE)
            val offset = idx * step
            for (i in tone.indices) {
                if (offset + i < total) {
                    val mixed = out[offset + i].toInt() + tone[i].toInt()
                    out[offset + i] = mixed.coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
                }
            }
        }
        return out
    }

    private fun mix(a: ShortArray, b: ShortArray): ShortArray {
        val len = maxOf(a.size, b.size)
        val out = ShortArray(len)
        for (i in 0 until len) {
            val va = if (i < a.size) a[i].toInt() else 0
            val vb = if (i < b.size) b[i].toInt() else 0
            out[i] = (va + vb).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
        }
        return out
    }
}
