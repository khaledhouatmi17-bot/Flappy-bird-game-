package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.PlayerRepository
import com.example.model.FlightRecord
import com.example.model.MedalTier
import com.example.model.PlayerProfile
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class LastFlightSummary(
    val score: Int,
    val bestScore: Int,
    val stageReached: Int,
    val coinsEarned: Int,
    val isNewBest: Boolean,
    val medal: MedalTier
)

enum class ActiveModal {
    NONE,
    MENU,
    HANGAR,
    FLIGHT_LOG,
    SETTINGS,
    PAUSED,
    GAME_OVER
}

class GameViewModel(
    private val repository: PlayerRepository
) : ViewModel() {

    val profile: StateFlow<PlayerProfile> = repository.profileFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = PlayerProfile()
        )

    val recentFlights: StateFlow<List<FlightRecord>> = repository.recentFlightsFlow
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000L),
            initialValue = emptyList()
        )

    private val _activeModal = MutableStateFlow(ActiveModal.MENU)
    val activeModal: StateFlow<ActiveModal> = _activeModal.asStateFlow()

    private val _lastFlight = MutableStateFlow<LastFlightSummary?>(null)
    val lastFlight: StateFlow<LastFlightSummary?> = _lastFlight.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    fun setActiveModal(modal: ActiveModal) {
        _activeModal.value = modal
    }

    fun clearStatusMessage() {
        _statusMessage.value = null
    }

    fun onFlightCompleted(
        score: Int,
        stageReached: Int,
        coinsEarned: Int,
        isNewBest: Boolean,
        skinId: String
    ) {
        val currentProfile = profile.value
        val previousBest = currentProfile.bestScore
        val updatedBest = maxOf(previousBest, score)

        _lastFlight.value = LastFlightSummary(
            score = score,
            bestScore = updatedBest,
            stageReached = stageReached,
            coinsEarned = coinsEarned,
            isNewBest = isNewBest && score > previousBest,
            medal = MedalTier.fromScore(score)
        )
        _activeModal.value = ActiveModal.GAME_OVER

        viewModelScope.launch {
            repository.recordCompletedFlight(
                score = score,
                stageReached = stageReached,
                coinsEarned = coinsEarned,
                skinId = skinId
            ).onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to save score locally"
            }
        }
    }

    fun selectOrUnlockSkin(skinId: String) {
        viewModelScope.launch {
            repository.unlockOrEquipSkin(skinId)
                .onSuccess { newlyUnlocked ->
                    if (newlyUnlocked) {
                        _statusMessage.value = "Skin unlocked & equipped!"
                    }
                }
                .onFailure { err ->
                    _statusMessage.value = err.localizedMessage ?: "Cannot equip skin"
                }
        }
    }

    fun updateSettings(
        soundEnabled: Boolean,
        musicEnabled: Boolean,
        dayNightCycle: Boolean,
        diffProgression: Boolean
    ) {
        viewModelScope.launch {
            repository.updateSettings(
                soundEnabled = soundEnabled,
                musicEnabled = musicEnabled,
                dayNightCycle = dayNightCycle,
                diffProgression = diffProgression
            ).onFailure { err ->
                _statusMessage.value = err.localizedMessage ?: "Failed to save settings"
            }
        }
    }
}
