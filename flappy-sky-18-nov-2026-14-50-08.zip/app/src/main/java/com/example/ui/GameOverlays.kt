package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.MonetizationOn
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.game.drawBirdGraphic
import com.example.model.BIRD_SKINS
import com.example.model.BirdSkin
import com.example.model.FlightRecord
import com.example.model.GamePhase
import com.example.model.PlayerProfile
import com.example.model.findBirdSkin
import com.example.model.stageForLevel
import com.example.ui.theme.CelestialCyan
import com.example.ui.theme.CelestialViolet
import com.example.ui.theme.CloudWhite
import com.example.ui.theme.CrimsonFlame
import com.example.ui.theme.EmeraldWing
import com.example.ui.theme.SkyDeepNavy
import com.example.ui.theme.SkySurface
import com.example.ui.theme.SkySurfaceVariant
import com.example.ui.theme.SlateInk
import com.example.ui.theme.SlateMuted
import com.example.ui.theme.SolarAmber
import com.example.ui.theme.SolarGold

@Composable
fun BirdPreviewCanvas(
    skin: BirdSkin,
    stage: Int,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "bird_preview_${skin.id}")
    val wingPhase by transition.animateFloat(
        initialValue = 0f,
        targetValue = (Math.PI * 2.0).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "preview_wing"
    )
    Canvas(modifier = modifier) {
        val scaleMod = (size.minDimension / 52f).coerceIn(0.6f, 2.2f)
        drawBirdGraphic(
            cx = size.width * 0.5f,
            cy = size.height * 0.52f,
            skin = skin,
            wingPhase = wingPhase,
            scaleMod = scaleMod,
            stage = stage,
            time = wingPhase
        )
    }
}

@Composable
fun GameHudTopBar(
    phase: GamePhase,
    score: Int,
    stageLevel: Int,
    coinsDisplayed: Int,
    onPauseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val stage = stageForLevel(stageLevel)
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (phase == GamePhase.PLAYING || phase == GamePhase.READY) {
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = SkySurface.copy(alpha = 0.85f),
                border = BorderStroke(2.dp, CloudWhite.copy(alpha = 0.35f))
            ) {
                IconButton(
                    onClick = onPauseClick,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("pause_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Pause,
                        contentDescription = "Pause Game",
                        tint = CloudWhite
                    )
                }
            }
        } else {
            Spacer(modifier = Modifier.size(48.dp))
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = score.toString(),
                style = MaterialTheme.typography.displayLarge.copy(
                    fontSize = 30.sp,
                    shadow = Shadow(color = Color.Black, blurRadius = 8f)
                ),
                color = CloudWhite
            )
            if (phase == GamePhase.PLAYING) {
                Surface(
                    color = SkyDeepNavy.copy(alpha = 0.72f),
                    shape = RoundedCornerShape(50),
                    border = BorderStroke(1.dp, stage.accentColor.copy(alpha = 0.65f))
                ) {
                    Text(
                        text = "S${stage.level} • ${stage.name}",
                        style = MaterialTheme.typography.labelSmall,
                        color = stage.accentColor,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 3.dp)
                    )
                }
            }
        }

        Surface(
            shape = RoundedCornerShape(50),
            color = SkyDeepNavy.copy(alpha = 0.78f),
            border = BorderStroke(2.dp, SolarGold)
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.MonetizationOn,
                    contentDescription = "Coins",
                    tint = SolarGold,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = coinsDisplayed.toString(),
                    style = MaterialTheme.typography.labelLarge,
                    color = Color(0xFFFEF08A)
                )
            }
        }
    }
}

@Composable
fun StageEvolutionBanner(
    stageLevel: Int,
    bannerTimer: Float,
    modifier: Modifier = Modifier
) {
    val stage = stageForLevel(stageLevel)
    AnimatedVisibility(
        visible = bannerTimer > 0f,
        enter = fadeIn() + scaleIn(initialScale = 0.85f),
        exit = fadeOut() + scaleOut(targetScale = 0.9f),
        modifier = modifier
    ) {
        Surface(
            color = SkyDeepNavy.copy(alpha = 0.86f),
            shape = RoundedCornerShape(18.dp),
            border = BorderStroke(2.dp, stage.accentColor)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = stage.name,
                    style = MaterialTheme.typography.headlineSmall,
                    color = CloudWhite
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = "STAGE ${stage.level}  •  ${stage.subtitle}",
                    style = MaterialTheme.typography.labelSmall,
                    color = stage.accentColor
                )
            }
        }
    }
}

@Composable
fun ReadyTapHint(
    visible: Boolean,
    modifier: Modifier = Modifier
) {
    val transition = rememberInfiniteTransition(label = "ready_bounce")
    val offsetY by transition.animateFloat(
        initialValue = -6f,
        targetValue = 8f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 650),
            repeatMode = RepeatMode.Reverse
        ),
        label = "bounce_y"
    )
    AnimatedVisibility(
        visible = visible,
        enter = fadeIn(),
        exit = fadeOut(),
        modifier = modifier
    ) {
        Surface(
            color = SkyDeepNavy.copy(alpha = 0.72f),
            shape = RoundedCornerShape(20.dp),
            border = BorderStroke(1.5.dp, SolarGold.copy(alpha = 0.75f)),
            modifier = Modifier.padding(top = (offsetY + 6f).dp)
        ) {
            Column(
                modifier = Modifier.padding(horizontal = 22.dp, vertical = 14.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = "Tap to fly",
                    tint = SolarGold,
                    modifier = Modifier.size(36.dp)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = stringResource(R.string.tap_to_fly),
                    style = MaterialTheme.typography.labelLarge,
                    color = CloudWhite,
                    textAlign = TextAlign.Center
                )
            }
        }
    }
}

@Composable
fun ModalBackdrop(
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xB8090D27))
            .safeDrawingPadding()
            .padding(16.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier
                .widthIn(max = 420.dp)
                .fillMaxWidth(),
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = SkySurface),
            border = BorderStroke(2.5.dp, CelestialCyan.copy(alpha = 0.55f))
        ) {
            Column(
                modifier = Modifier
                    .verticalScroll(rememberScrollState())
                    .padding(22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                content()
            }
        }
    }
}

@Composable
fun MainMenuOverlay(
    profile: PlayerProfile,
    onPlayClick: () -> Unit,
    onHangarClick: () -> Unit,
    onFlightLogClick: () -> Unit,
    onSettingsClick: () -> Unit
) {
    val activeSkin = findBirdSkin(profile.selectedSkin)
    val highestStage = stageForLevel(profile.highestStage)

    ModalBackdrop {
        Text(
            text = stringResource(R.string.game_title),
            style = MaterialTheme.typography.displayLarge,
            color = SolarAmber,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = stringResource(R.string.game_subtitle),
            style = MaterialTheme.typography.labelLarge,
            color = CelestialCyan,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(14.dp))

        Box(
            modifier = Modifier
                .size(92.dp)
                .clip(CircleShape)
                .background(
                    Brush.radialGradient(
                        colors = listOf(CelestialViolet.copy(alpha = 0.28f), SkyDeepNavy)
                    )
                ),
            contentAlignment = Alignment.Center
        ) {
            BirdPreviewCanvas(
                skin = activeSkin,
                stage = profile.highestStage.coerceIn(1, 6),
                modifier = Modifier.size(82.dp)
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        Surface(
            color = SkySurfaceVariant,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.5.dp, CloudWhite.copy(alpha = 0.14f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatRow("BEST SCORE", profile.bestScore.toString(), CloudWhite)
                StatRow("HIGHEST STAGE", "S${highestStage.level} • ${highestStage.name}", highestStage.accentColor)
                StatRow("TOTAL COINS", profile.totalCoins.toString(), SolarGold)
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        ArcadeActionButton(
            text = stringResource(R.string.play_now),
            icon = Icons.Default.PlayArrow,
            containerColor = EmeraldWing,
            contentColor = SlateInk,
            testTag = "play_button",
            onClick = onPlayClick
        )
        Spacer(modifier = Modifier.height(10.dp))

        ArcadeActionButton(
            text = stringResource(R.string.bird_hangar),
            icon = Icons.Default.AutoAwesome,
            containerColor = CelestialCyan,
            contentColor = SlateInk,
            testTag = "hangar_button",
            onClick = onHangarClick
        )
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ArcadeActionButton(
                text = "LOG",
                icon = Icons.Default.History,
                containerColor = CelestialViolet,
                contentColor = SlateInk,
                testTag = "flight_log_button",
                onClick = onFlightLogClick,
                modifier = Modifier.weight(1f)
            )
            ArcadeActionButton(
                text = "OPTS",
                icon = Icons.Default.Settings,
                containerColor = SolarAmber,
                contentColor = SlateInk,
                testTag = "settings_button",
                onClick = onSettingsClick,
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
fun HangarOverlay(
    profile: PlayerProfile,
    onSelectSkin: (String) -> Unit,
    onBack: () -> Unit
) {
    ModalBackdrop {
        Text(
            text = stringResource(R.string.bird_hangar),
            style = MaterialTheme.typography.displayMedium,
            color = CelestialCyan
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "TOTAL COINS: ${profile.totalCoins}",
            style = MaterialTheme.typography.labelLarge,
            color = SolarGold
        )
        Spacer(modifier = Modifier.height(14.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier
                .fillMaxWidth()
                .height(340.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(BIRD_SKINS, key = { it.id }) { skin ->
                val isUnlocked = skin.id in profile.unlockedSkins
                val isSelected = skin.id == profile.selectedSkin
                val canAfford = profile.totalCoins >= skin.unlockCost
                val borderColor = when {
                    isSelected -> EmeraldWing
                    isUnlocked -> CelestialCyan.copy(alpha = 0.5f)
                    canAfford -> SolarGold.copy(alpha = 0.6f)
                    else -> SlateMuted.copy(alpha = 0.35f)
                }

                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = if (isSelected) EmeraldWing.copy(alpha = 0.14f) else SkySurfaceVariant,
                    border = BorderStroke(2.dp, borderColor),
                    modifier = Modifier
                        .fillMaxWidth()
                        .minimumInteractiveComponentSize()
                        .clickable { onSelectSkin(skin.id) }
                        .testTag("skin_card_${skin.id}")
                ) {
                    Column(
                        modifier = Modifier.padding(10.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        BirdPreviewCanvas(
                            skin = skin,
                            stage = profile.highestStage.coerceIn(1, 6),
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = skin.name,
                            style = MaterialTheme.typography.labelSmall,
                            color = CloudWhite,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = when {
                                isSelected -> "EQUIPPED"
                                isUnlocked -> "TAP TO EQUIP"
                                else -> "UNLOCK: ${skin.unlockCost} COINS"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = when {
                                isSelected -> EmeraldWing
                                isUnlocked -> CelestialCyan
                                canAfford -> SolarGold
                                else -> SlateMuted
                            }
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        ArcadeActionButton(
            text = stringResource(R.string.back),
            icon = null,
            containerColor = CelestialCyan,
            contentColor = SlateInk,
            testTag = "hangar_back_button",
            onClick = onBack
        )
    }
}

@Composable
fun FlightLogOverlay(
    flights: List<FlightRecord>,
    onBack: () -> Unit
) {
    ModalBackdrop {
        Text(
            text = stringResource(R.string.flight_log),
            style = MaterialTheme.typography.displayMedium,
            color = CelestialViolet
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "RECENT LOCAL RUNS",
            style = MaterialTheme.typography.labelSmall,
            color = SlateMuted
        )
        Spacer(modifier = Modifier.height(14.dp))

        if (flights.isEmpty()) {
            Surface(
                color = SkySurfaceVariant,
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = Icons.Default.History,
                        contentDescription = null,
                        tint = CelestialCyan,
                        modifier = Modifier.size(36.dp)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "No flights recorded yet.\nTap Play Now to take off!",
                        style = MaterialTheme.typography.bodyMedium,
                        color = SlateMuted,
                        textAlign = TextAlign.Center
                    )
                }
            }
        } else {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                flights.take(8).forEach { record ->
                    val stage = stageForLevel(record.stageReached)
                    val skin = findBirdSkin(record.skinId)
                    Surface(
                        color = SkySurfaceVariant,
                        shape = RoundedCornerShape(14.dp),
                        border = BorderStroke(1.dp, stage.accentColor.copy(alpha = 0.35f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = "${record.score} PTS  •  ${skin.shortName}",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = CloudWhite
                                )
                                Text(
                                    text = "Stage ${stage.level}: ${stage.name}",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = stage.accentColor
                                )
                            }
                            Text(
                                text = "+${record.coinsEarned} 🪙",
                                style = MaterialTheme.typography.labelLarge,
                                color = SolarGold
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        ArcadeActionButton(
            text = stringResource(R.string.back),
            icon = null,
            containerColor = CelestialViolet,
            contentColor = SlateInk,
            testTag = "flight_log_back_button",
            onClick = onBack
        )
    }
}

@Composable
fun SettingsOverlay(
    profile: PlayerProfile,
    onUpdateSettings: (Boolean, Boolean, Boolean, Boolean) -> Unit,
    onDone: () -> Unit
) {
    ModalBackdrop {
        Text(
            text = stringResource(R.string.settings),
            style = MaterialTheme.typography.displayMedium,
            color = SolarAmber
        )
        Spacer(modifier = Modifier.height(12.dp))

        SettingToggleRow(
            label = "SOUND SFX",
            checked = profile.soundEnabled,
            testTag = "toggle_sound",
            onCheckedChange = {
                onUpdateSettings(it, profile.musicEnabled, profile.dayNightCycle, profile.diffProgression)
            }
        )
        SettingToggleRow(
            label = "CHIPTUNE MUSIC",
            checked = profile.musicEnabled,
            testTag = "toggle_music",
            onCheckedChange = {
                onUpdateSettings(profile.soundEnabled, it, profile.dayNightCycle, profile.diffProgression)
            }
        )
        SettingToggleRow(
            label = "DAY / NIGHT CYCLE",
            checked = profile.dayNightCycle,
            testTag = "toggle_day_night",
            onCheckedChange = {
                onUpdateSettings(profile.soundEnabled, profile.musicEnabled, it, profile.diffProgression)
            }
        )
        SettingToggleRow(
            label = "DIFFICULTY PROGRESSION",
            checked = profile.diffProgression,
            testTag = "toggle_diff_prog",
            onCheckedChange = {
                onUpdateSettings(profile.soundEnabled, profile.musicEnabled, profile.dayNightCycle, it)
            }
        )

        Spacer(modifier = Modifier.height(16.dp))
        ArcadeActionButton(
            text = stringResource(R.string.done),
            icon = null,
            containerColor = CelestialCyan,
            contentColor = SlateInk,
            testTag = "settings_done_button",
            onClick = onDone
        )
    }
}

@Composable
fun PauseOverlay(
    onResume: () -> Unit,
    onRetry: () -> Unit,
    onMainMenu: () -> Unit
) {
    ModalBackdrop {
        Text(
            text = stringResource(R.string.paused),
            style = MaterialTheme.typography.displayMedium,
            color = CelestialCyan
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "TAKE A BREATHER",
            style = MaterialTheme.typography.labelSmall,
            color = SlateMuted
        )
        Spacer(modifier = Modifier.height(18.dp))

        ArcadeActionButton(
            text = stringResource(R.string.resume),
            icon = Icons.Default.PlayArrow,
            containerColor = EmeraldWing,
            contentColor = SlateInk,
            testTag = "resume_button",
            onClick = onResume
        )
        Spacer(modifier = Modifier.height(10.dp))
        ArcadeActionButton(
            text = "RETRY",
            icon = Icons.Default.Refresh,
            containerColor = SolarAmber,
            contentColor = SlateInk,
            testTag = "pause_retry_button",
            onClick = onRetry
        )
        Spacer(modifier = Modifier.height(10.dp))
        ArcadeActionButton(
            text = stringResource(R.string.main_menu),
            icon = null,
            containerColor = CelestialCyan,
            contentColor = SlateInk,
            testTag = "pause_menu_button",
            onClick = onMainMenu
        )
    }
}

@Composable
fun GameOverOverlay(
    summary: LastFlightSummary,
    onRetry: () -> Unit,
    onShare: () -> Unit,
    onMainMenu: () -> Unit
) {
    val stage = stageForLevel(summary.stageReached)

    ModalBackdrop {
        Text(
            text = stringResource(R.string.game_over),
            style = MaterialTheme.typography.displayMedium,
            color = CrimsonFlame
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = if (summary.isNewBest) "★ NEW HIGH SCORE! ★" else "FLIGHT COMPLETE",
            style = MaterialTheme.typography.labelLarge,
            color = if (summary.isNewBest) SolarGold else SlateMuted,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(16.dp))

        Surface(
            color = SkySurfaceVariant,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(1.5.dp, CloudWhite.copy(alpha = 0.14f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                StatRow("SCORE", summary.score.toString(), CloudWhite)
                StatRow("BEST", summary.bestScore.toString(), SolarGold)
                StatRow("STAGE", "S${stage.level} • ${stage.name}", stage.accentColor)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "MEDAL",
                        style = MaterialTheme.typography.labelSmall,
                        color = SlateMuted
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(summary.medal.color),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = summary.medal.symbol,
                                color = CloudWhite,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Text(
                            text = summary.medal.label,
                            style = MaterialTheme.typography.labelLarge,
                            color = CloudWhite
                        )
                    }
                }
                StatRow("COINS EARNED", "+${summary.coinsEarned}", SolarGold)
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        ArcadeActionButton(
            text = stringResource(R.string.retry),
            icon = Icons.Default.Refresh,
            containerColor = EmeraldWing,
            contentColor = SlateInk,
            testTag = "retry_button",
            onClick = onRetry
        )
        Spacer(modifier = Modifier.height(10.dp))
        ArcadeActionButton(
            text = stringResource(R.string.share_score),
            icon = Icons.Default.Share,
            containerColor = CelestialCyan,
            contentColor = SlateInk,
            testTag = "share_score_button",
            onClick = onShare
        )
        Spacer(modifier = Modifier.height(10.dp))
        ArcadeActionButton(
            text = stringResource(R.string.main_menu),
            icon = null,
            containerColor = SolarAmber,
            contentColor = SlateInk,
            testTag = "gameover_menu_button",
            onClick = onMainMenu
        )
    }
}

@Composable
private fun StatRow(label: String, value: String, valueColor: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = SlateMuted
        )
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium,
            color = valueColor
        )
    }
}

@Composable
private fun SettingToggleRow(
    label: String,
    checked: Boolean,
    testTag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = CloudWhite,
                modifier = Modifier.weight(1f)
            )
            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = CloudWhite,
                    checkedTrackColor = EmeraldWing,
                    uncheckedThumbColor = SlateMuted,
                    uncheckedTrackColor = SkySurfaceVariant
                ),
                modifier = Modifier.testTag(testTag)
            )
        }
        HorizontalDivider(color = CloudWhite.copy(alpha = 0.08f))
    }
}

@Composable
private fun ArcadeActionButton(
    text: String,
    icon: ImageVector?,
    containerColor: Color,
    contentColor: Color,
    testTag: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = containerColor,
            contentColor = contentColor
        ),
        shape = RoundedCornerShape(14.dp),
        modifier = modifier
            .fillMaxWidth()
            .minimumInteractiveComponentSize()
            .height(50.dp)
            .testTag(testTag)
    ) {
        if (icon != null) {
            Icon(imageVector = icon, contentDescription = null, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
        }
        Text(
            text = text,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}
