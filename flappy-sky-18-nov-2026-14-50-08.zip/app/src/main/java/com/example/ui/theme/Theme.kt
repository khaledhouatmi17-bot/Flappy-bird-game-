package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.unit.dp

private val FlappyColorScheme = darkColorScheme(
    primary = CelestialCyan,
    onPrimary = SlateInk,
    primaryContainer = SkySurfaceVariant,
    onPrimaryContainer = CloudWhite,
    secondary = EmeraldWing,
    onSecondary = SlateInk,
    tertiary = CelestialViolet,
    onTertiary = SlateInk,
    background = SkyDeepNavy,
    onBackground = CloudWhite,
    surface = SkySurface,
    onSurface = CloudWhite,
    surfaceVariant = SkySurfaceVariant,
    onSurfaceVariant = SlateMuted,
    error = CrimsonFlame,
    onError = CloudWhite
)

private val FlappyShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp)
)

@Composable
fun FlappySkyTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = FlappyColorScheme,
        typography = FlappyTypography,
        shapes = FlappyShapes,
        content = content
    )
}
