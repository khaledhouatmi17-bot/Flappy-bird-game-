package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val SkyDeepNavy = Color(0xFF090D27)
val SkySurface = Color(0xFF111936)
val SkySurfaceVariant = Color(0xFF1B274F)
val SkyCardLight = Color(0xFFFDFAF0)

val CelestialCyan = Color(0xFF38BDF8)
val CelestialViolet = Color(0xFFC084FC)
val SolarAmber = Color(0xFFF59E0B)
val SolarGold = Color(0xFFFACC15)
val EmeraldWing = Color(0xFF22C55E)
val CrimsonFlame = Color(0xFFEF4444)
val SlateInk = Color(0xFF0F172A)
val SlateMuted = Color(0xFF94A3B8)
val CloudWhite = Color(0xFFF8FAFC)
