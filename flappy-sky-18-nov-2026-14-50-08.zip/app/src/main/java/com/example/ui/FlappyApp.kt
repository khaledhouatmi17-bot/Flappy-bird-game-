package com.example.ui

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.Companion.APPLICATION_KEY
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.audio.SoundEngine
import com.example.data.PlayerRepository
import com.example.game.FlappyGameEngine
import com.example.game.renderFlappyWorld
import com.example.model.GamePhase
import com.example.model.MedalTier
import com.example.model.findBirdSkin
import com.example.model.stageForLevel

@Composable
fun FlappySkyApp() {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current

    val viewModel: GameViewModel = viewModel(
        factory = viewModelFactory {
            initializer {
                val app = checkNotNull(this[APPLICATION_KEY]) {
                    "APPLICATION_KEY missing from CreationExtras"
                }
                GameViewModel(PlayerRepository(app))
            }
        }
    )

    val profile by viewModel.profile.collectAsStateWithLifecycle()
    val recentFlights by viewModel.recentFlights.collectAsStateWithLifecycle()
    val activeModal by viewModel.activeModal.collectAsStateWithLifecycle()
    val lastFlight by viewModel.lastFlight.collectAsStateWithLifecycle()
    val statusMessage by viewModel.statusMessage.collectAsStateWithLifecycle()

    val soundEngine = remember { SoundEngine() }

    val gameEngine = remember {
        FlappyGameEngine(
            onFlapSfx = { soundEngine.playFlap() },
            onScoreSfx = { soundEngine.playScore() },
            onCoinSfx = { soundEngine.playCoin() },
            onHitSfx = { soundEngine.playHit() },
            onStageUpSfx = { soundEngine.playMedal() },
            onRecordCelebrationSfx = { soundEngine.playMedal() },
            onHapticImpact = { heavy ->
                haptic.performHapticFeedback(
                    if (heavy) HapticFeedbackType.LongPress else HapticFeedbackType.TextHandleMove
                )
            },
            onFlightFinished = { score, stageReached, coinsEarned, isNewBest ->
                soundEngine.stopMusic()
                viewModel.onFlightCompleted(
                    score = score,
                    stageReached = stageReached,
                    coinsEarned = coinsEarned,
                    isNewBest = isNewBest,
                    skinId = profile.selectedSkin
                )
            }
        )
    }

    // Keep engine & sound engine synced with local preferences
    LaunchedEffect(profile) {
        soundEngine.soundEnabled = profile.soundEnabled
        soundEngine.musicEnabled = profile.musicEnabled
        gameEngine.dayNightEnabled = profile.dayNightCycle
        gameEngine.diffProgressionEnabled = profile.diffProgression
        gameEngine.currentSkinId = profile.selectedSkin
        gameEngine.bestScoreKnown = profile.bestScore
        if (profile.musicEnabled && gameEngine.phase == GamePhase.PLAYING) {
            soundEngine.startMusic()
        } else if (!profile.musicEnabled) {
            soundEngine.stopMusic()
        }
    }

    DisposableEffect(Unit) {
        onDispose {
            soundEngine.release()
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_PAUSE) {
                soundEngine.stopMusic()
                if (gameEngine.phase == GamePhase.PLAYING) {
                    gameEngine.pauseIfPlaying()
                    viewModel.setActiveModal(ActiveModal.PAUSED)
                }
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    LaunchedEffect(gameEngine) {
        var lastNanos = 0L
        while (true) {
            withFrameNanos { frameNanos ->
                if (lastNanos != 0L) {
                    val dt = (frameNanos - lastNanos) / 1_000_000_000f
                    gameEngine.step(dt)
                }
                lastNanos = frameNanos
            }
        }
    }

    BackHandler(enabled = activeModal != ActiveModal.MENU) {
        when (activeModal) {
            ActiveModal.HANGAR, ActiveModal.FLIGHT_LOG, ActiveModal.SETTINGS -> {
                viewModel.setActiveModal(ActiveModal.MENU)
            }
            ActiveModal.PAUSED -> {
                viewModel.setActiveModal(ActiveModal.NONE)
                gameEngine.resumeFromPause()
                if (profile.musicEnabled) soundEngine.startMusic()
            }
            ActiveModal.GAME_OVER -> {
                gameEngine.returnToMenu()
                viewModel.setActiveModal(ActiveModal.MENU)
            }
            ActiveModal.NONE -> {
                if (gameEngine.phase == GamePhase.PLAYING) {
                    gameEngine.pauseIfPlaying()
                    soundEngine.stopMusic()
                    viewModel.setActiveModal(ActiveModal.PAUSED)
                } else {
                    gameEngine.returnToMenu()
                    soundEngine.stopMusic()
                    viewModel.setActiveModal(ActiveModal.MENU)
                }
            }
            ActiveModal.MENU -> Unit
        }
    }

    val snackbarHostState = remember { SnackbarHostState() }
    LaunchedEffect(statusMessage) {
        val msg = statusMessage ?: return@LaunchedEffect
        snackbarHostState.showSnackbar(msg)
        viewModel.clearStatusMessage()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        modifier = Modifier.fillMaxSize()
    ) { _ ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .focusable()
                .onKeyEvent { keyEvent ->
                    if (keyEvent.type == KeyEventType.KeyDown) {
                        when (keyEvent.key) {
                            Key.Spacebar, Key.DirectionUp -> {
                                if (activeModal == ActiveModal.NONE &&
                                    (gameEngine.phase == GamePhase.READY || gameEngine.phase == GamePhase.PLAYING)
                                ) {
                                    val wasReady = gameEngine.phase == GamePhase.READY
                                    gameEngine.onTapAction()
                                    if (wasReady && profile.musicEnabled) soundEngine.startMusic()
                                    true
                                } else false
                            }
                            Key.P, Key.Escape -> {
                                if (gameEngine.phase == GamePhase.PLAYING) {
                                    gameEngine.pauseIfPlaying()
                                    soundEngine.stopMusic()
                                    viewModel.setActiveModal(ActiveModal.PAUSED)
                                    true
                                } else false
                            }
                            else -> false
                        }
                    } else false
                }
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("game_canvas")
                    .pointerInput(activeModal) {
                        detectTapGestures(
                            onPress = {
                                if (activeModal == ActiveModal.NONE &&
                                    (gameEngine.phase == GamePhase.READY || gameEngine.phase == GamePhase.PLAYING)
                                ) {
                                    val wasReady = gameEngine.phase == GamePhase.READY
                                    gameEngine.onTapAction()
                                    if (wasReady && profile.musicEnabled) {
                                        soundEngine.startMusic()
                                    }
                                }
                            }
                        )
                    }
            ) {
                renderFlappyWorld(gameEngine)
            }

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .safeDrawingPadding()
            ) {
                GameHudTopBar(
                    phase = gameEngine.phase,
                    score = gameEngine.score,
                    stageLevel = gameEngine.stageLevel,
                    coinsDisplayed = if (gameEngine.phase == GamePhase.PLAYING) {
                        gameEngine.sessionCoins
                    } else {
                        profile.totalCoins
                    },
                    onPauseClick = {
                        if (gameEngine.phase == GamePhase.PLAYING) {
                            gameEngine.pauseIfPlaying()
                            soundEngine.stopMusic()
                            viewModel.setActiveModal(ActiveModal.PAUSED)
                        } else if (gameEngine.phase == GamePhase.READY) {
                            gameEngine.returnToMenu()
                            viewModel.setActiveModal(ActiveModal.MENU)
                        }
                    },
                    modifier = Modifier.align(Alignment.TopCenter)
                )

                StageEvolutionBanner(
                    stageLevel = gameEngine.stageLevel,
                    bannerTimer = gameEngine.stageBannerTimer,
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 84.dp)
                )

                ReadyTapHint(
                    visible = activeModal == ActiveModal.NONE && gameEngine.phase == GamePhase.READY,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .padding(top = 120.dp)
                )
            }

            when (activeModal) {
                ActiveModal.MENU -> {
                    MainMenuOverlay(
                        profile = profile,
                        onPlayClick = {
                            gameEngine.prepareReady()
                            viewModel.setActiveModal(ActiveModal.NONE)
                        },
                        onHangarClick = {
                            viewModel.setActiveModal(ActiveModal.HANGAR)
                        },
                        onFlightLogClick = {
                            viewModel.setActiveModal(ActiveModal.FLIGHT_LOG)
                        },
                        onSettingsClick = {
                            viewModel.setActiveModal(ActiveModal.SETTINGS)
                        }
                    )
                }
                ActiveModal.HANGAR -> {
                    HangarOverlay(
                        profile = profile,
                        onSelectSkin = { skinId ->
                            val isUnlocked = skinId in profile.unlockedSkins
                            val cost = findBirdSkin(skinId).unlockCost
                            if (isUnlocked || profile.totalCoins >= cost) {
                                soundEngine.playCoin()
                            } else {
                                soundEngine.playHit()
                            }
                            viewModel.selectOrUnlockSkin(skinId)
                        },
                        onBack = { viewModel.setActiveModal(ActiveModal.MENU) }
                    )
                }
                ActiveModal.FLIGHT_LOG -> {
                    FlightLogOverlay(
                        flights = recentFlights,
                        onBack = { viewModel.setActiveModal(ActiveModal.MENU) }
                    )
                }
                ActiveModal.SETTINGS -> {
                    SettingsOverlay(
                        profile = profile,
                        onUpdateSettings = { sfx, music, dayNight, diff ->
                            viewModel.updateSettings(sfx, music, dayNight, diff)
                        },
                        onDone = { viewModel.setActiveModal(ActiveModal.MENU) }
                    )
                }
                ActiveModal.PAUSED -> {
                    PauseOverlay(
                        onResume = {
                            viewModel.setActiveModal(ActiveModal.NONE)
                            gameEngine.resumeFromPause()
                            if (profile.musicEnabled) soundEngine.startMusic()
                        },
                        onRetry = {
                            soundEngine.stopMusic()
                            gameEngine.prepareReady()
                            viewModel.setActiveModal(ActiveModal.NONE)
                        },
                        onMainMenu = {
                            soundEngine.stopMusic()
                            gameEngine.returnToMenu()
                            viewModel.setActiveModal(ActiveModal.MENU)
                        }
                    )
                }
                ActiveModal.GAME_OVER -> {
                    val summary = lastFlight ?: LastFlightSummary(
                        score = gameEngine.score,
                        bestScore = maxOf(profile.bestScore, gameEngine.score),
                        stageReached = gameEngine.highestStageInRun,
                        coinsEarned = gameEngine.sessionCoins,
                        isNewBest = false,
                        medal = MedalTier.fromScore(gameEngine.score)
                    )
                    GameOverOverlay(
                        summary = summary,
                        onRetry = {
                            gameEngine.prepareReady()
                            viewModel.setActiveModal(ActiveModal.NONE)
                        },
                        onShare = {
                            val stageName = stageForLevel(summary.stageReached).name
                            val shareText = "I scored ${summary.score} pts (Stage ${summary.stageReached}: $stageName) in Flappy Sky: Evolution! Can you beat my record?"
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Flappy Sky: Evolution")
                                putExtra(Intent.EXTRA_TEXT, shareText)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Share Score"))
                        },
                        onMainMenu = {
                            gameEngine.returnToMenu()
                            viewModel.setActiveModal(ActiveModal.MENU)
                        }
                    )
                }
                ActiveModal.NONE -> Unit
            }
        }
    }
}
