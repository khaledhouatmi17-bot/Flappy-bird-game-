package com.example.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.example.model.GamePhase
import com.example.model.stageLevelForScore
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

const val WORLD_W = 360f
const val WORLD_H = 640f
const val GROUND_HEIGHT = 90f

data class CloudEntity(
    var x: Float,
    var y: Float,
    val w: Float,
    val h: Float,
    val speed: Float
)

data class HillEntity(
    val x: Float,
    val y: Float,
    val r: Float
)

data class CoinEntity(
    val y: Float,
    var collected: Boolean = false,
    var animTimer: Float = 0f
)

data class PipePairEntity(
    var x: Float,
    val w: Float = 56f,
    val topHeight: Float,
    val bottomY: Float,
    val gap: Float,
    var scored: Boolean = false,
    val coin: CoinEntity? = null
)

data class ParticleEntity(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    val size: Float,
    val color: Color,
    var life: Float,
    val maxLife: Float
)

data class WeatherParticle(
    var x: Float,
    var y: Float,
    val vx: Float,
    val vy: Float,
    val size: Float,
    var life: Float
)

class FlappyGameEngine(
    private val onFlapSfx: () -> Unit,
    private val onScoreSfx: () -> Unit,
    private val onCoinSfx: () -> Unit,
    private val onHitSfx: () -> Unit,
    private val onStageUpSfx: () -> Unit,
    private val onRecordCelebrationSfx: () -> Unit,
    private val onHapticImpact: (heavy: Boolean) -> Unit,
    private val onFlightFinished: (score: Int, stageReached: Int, coinsEarned: Int, isNewBest: Boolean) -> Unit
) {
    // Frame counter bumped on each tick to invalidate Canvas cleanly without ViewModel churn
    var frameTick by mutableLongStateOf(0L)
        private set

    var phase by mutableStateOfPhase(GamePhase.MENU)
        private set

    var score by mutableIntStateOf(0)
        private set

    var sessionCoins by mutableIntStateOf(0)
        private set

    var stageLevel by mutableIntStateOf(1)
        private set

    var highestStageInRun by mutableIntStateOf(1)
        private set

    var stageBannerTimer by mutableFloatStateOf(0f)
        private set

    var dayNightEnabled: Boolean = true
    var diffProgressionEnabled: Boolean = true
    var currentSkinId: String = "classic"
    var bestScoreKnown: Int = 0

    // Physics constants
    private val gravity = 980f
    private val flapVelocity = -340f
    private val basePipeSpeed = 145f
    private val pipeInterval = 1.75f

    var pipeSpeed = basePipeSpeed
        private set
    var pipeGap = 135f
        private set
    private var pipeTimer = 0.8f

    // Bird state
    var birdX = 90f
    var birdY = 260f
    val birdW = 34f
    val birdH = 24f
    var birdVy = 0f
    var birdRotation = 0f
    var birdWingPhase = 0f
    var birdAlive = true

    // Environment & FX state
    var dayProgress = 0f
    private var dayDirection = 1f
    var visualTime = 0f
    var screenShake = 0f
    var groundX = 0f
    var lightningFlash = 0f
    private var lightningTimer = 4.5f

    val clouds = mutableListOf(
        CloudEntity(40f, 70f, 90f, 42f, 12f),
        CloudEntity(190f, 130f, 120f, 50f, 18f),
        CloudEntity(320f, 50f, 80f, 36f, 10f)
    )

    val distantHills = listOf(
        HillEntity(0f, WORLD_H - GROUND_HEIGHT - 40f, 85f),
        HillEntity(140f, WORLD_H - GROUND_HEIGHT - 55f, 110f),
        HillEntity(290f, WORLD_H - GROUND_HEIGHT - 45f, 95f),
        HillEntity(420f, WORLD_H - GROUND_HEIGHT - 50f, 105f)
    )

    val pipes = mutableListOf<PipePairEntity>()
    val particles = mutableListOf<ParticleEntity>()
    val weatherParticles = mutableListOf<WeatherParticle>()

    fun prepareReady() {
        resetFlightData()
        phase = GamePhase.READY
    }

    fun returnToMenu() {
        pipes.clear()
        particles.clear()
        weatherParticles.clear()
        score = 0
        sessionCoins = 0
        stageLevel = 1
        highestStageInRun = 1
        stageBannerTimer = 0f
        lightningFlash = 0f
        screenShake = 0f
        birdX = 90f
        birdY = 260f
        birdVy = 0f
        birdRotation = 0f
        birdAlive = true
        phase = GamePhase.MENU
    }

    fun pauseIfPlaying() {
        if (phase == GamePhase.PLAYING) {
            phase = GamePhase.PAUSED
        }
    }

    fun resumeFromPause() {
        if (phase == GamePhase.PAUSED) {
            phase = GamePhase.PLAYING
        }
    }

    fun onTapAction() {
        when (phase) {
            GamePhase.READY -> {
                phase = GamePhase.PLAYING
                flap()
            }
            GamePhase.PLAYING -> {
                flap()
            }
            else -> Unit
        }
    }

    private fun flap() {
        if (!birdAlive) return
        birdVy = flapVelocity
        onFlapSfx()
        repeat(4) {
            particles.add(
                ParticleEntity(
                    x = birdX - 4f,
                    y = birdY + birdH * 0.15f,
                    vx = -30f - Random.nextFloat() * 40f,
                    vy = (Random.nextFloat() - 0.5f) * 60f,
                    size = 3f + Random.nextFloat() * 3f,
                    color = Color.White,
                    life = 0.35f,
                    maxLife = 0.35f
                )
            )
        }
    }

    private fun resetFlightData() {
        birdX = 90f
        birdY = 260f
        birdVy = 0f
        birdRotation = 0f
        birdAlive = true
        pipes.clear()
        particles.clear()
        weatherParticles.clear()
        score = 0
        sessionCoins = 0
        pipeTimer = 0.8f
        pipeSpeed = basePipeSpeed
        pipeGap = 135f
        stageLevel = 1
        highestStageInRun = 1
        stageBannerTimer = 0f
        lightningFlash = 0f
        lightningTimer = 3f + Random.nextFloat() * 4f
        screenShake = 0f
    }

    fun step(rawDt: Float) {
        val dt = rawDt.coerceIn(0f, 0.05f)
        visualTime += dt
        screenShake = max(0f, screenShake - dt * 2.8f)

        updateWeather(dt)

        if (dayNightEnabled) {
            dayProgress += dt * 0.02f * dayDirection
            if (dayProgress >= 1f) {
                dayProgress = 1f
                dayDirection = -1f
            } else if (dayProgress <= 0f) {
                dayProgress = 0f
                dayDirection = 1f
            }
        } else {
            dayProgress = 0f
        }

        // Parallax clouds
        if (phase != GamePhase.PAUSED) {
            clouds.forEach { c ->
                c.x -= c.speed * dt
                if (c.x + c.w < 0f) {
                    c.x = WORLD_W + 40f
                    c.y = 40f + Random.nextFloat() * 120f
                }
            }
        }

        // Particles
        val pIter = particles.listIterator()
        while (pIter.hasNext()) {
            val p = pIter.next()
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.life -= dt
            if (p.life <= 0f) pIter.remove()
        }

        when (phase) {
            GamePhase.MENU, GamePhase.READY -> {
                groundX = (groundX - 80f * dt) % 24f
                birdWingPhase += dt * 8f
                birdY = 260f + sin(birdWingPhase * 0.7f) * 14f
                birdRotation = 0f
            }
            GamePhase.PLAYING -> {
                stepPlaying(dt)
            }
            GamePhase.PAUSED -> Unit
            GamePhase.GAME_OVER -> {
                val groundLimit = WORLD_H - GROUND_HEIGHT - birdH / 2f
                if (birdY < groundLimit) {
                    birdVy += gravity * dt
                    birdY += birdVy * dt
                    birdRotation = (PI / 2.0).toFloat()
                    if (birdY >= groundLimit) birdY = groundLimit
                }
            }
        }

        frameTick++
    }

    private fun stepPlaying(dt: Float) {
        groundX = (groundX - pipeSpeed * dt) % 24f

        if (diffProgressionEnabled) {
            pipeSpeed = basePipeSpeed + min(score * 1.5f, 65f)
            pipeGap = max(105f, 135f - score * 0.6f)
        } else {
            pipeSpeed = basePipeSpeed
            pipeGap = 135f
        }

        birdVy += gravity * dt
        birdY += birdVy * dt

        birdRotation = if (birdVy < -100f) {
            -0.38f
        } else {
            min((PI / 2.2).toFloat(), (birdVy - 50f) * 0.0028f)
        }
        birdWingPhase += dt * 14f

        pipeTimer -= dt
        if (pipeTimer <= 0f) {
            spawnPipePair()
            pipeTimer = pipeInterval
        }

        val birdLeft = birdX - birdW / 2f + 4f
        val birdTop = birdY - birdH / 2f + 4f
        val birdBoxW = birdW - 8f
        val birdBoxH = birdH - 8f

        val pipeIter = pipes.listIterator()
        while (pipeIter.hasNext()) {
            val p = pipeIter.next()
            p.x -= pipeSpeed * dt

            // Coin pickup check
            val coin = p.coin
            if (coin != null && !coin.collected) {
                coin.animTimer += dt * 5f
                val coinX = p.x + p.w / 2f
                val coinY = coin.y + sin(coin.animTimer) * 5f
                if (hypot(birdX - coinX, birdY - coinY) < 26f) {
                    coin.collected = true
                    sessionCoins++
                    onCoinSfx()
                    repeat(6) {
                        particles.add(
                            ParticleEntity(
                                x = coinX,
                                y = coinY,
                                vx = (Random.nextFloat() - 0.5f) * 120f,
                                vy = (Random.nextFloat() - 0.5f) * 120f,
                                size = 4f,
                                color = Color(0xFFFDE047),
                                life = 0.4f,
                                maxLife = 0.4f
                            )
                        )
                    }
                }
            }

            // AABB pipe collisions
            val topHit = checkAABB(
                birdLeft, birdTop, birdBoxW, birdBoxH,
                p.x - 5f, 0f, p.w + 10f, p.topHeight
            )
            val bottomHit = checkAABB(
                birdLeft, birdTop, birdBoxW, birdBoxH,
                p.x - 5f, p.bottomY, p.w + 10f, WORLD_H - GROUND_HEIGHT - p.bottomY
            )
            if (topHit || bottomHit) {
                killBird()
                return
            }

            // Single-trigger scoring
            if (!p.scored && p.x + p.w + 5f < birdLeft) {
                p.scored = true
                score++
                updateStageProgress()
                onScoreSfx()
            }

            if (p.x + p.w < -30f) {
                pipeIter.remove()
            }
        }

        // Ceiling & ground bounds
        if (birdY - birdH / 2f < 0f) {
            birdY = birdH / 2f
            birdVy = 0f
        }
        val groundLimit = WORLD_H - GROUND_HEIGHT - birdH / 2f
        if (birdY >= groundLimit) {
            birdY = groundLimit
            killBird()
        }
    }

    private fun spawnPipePair() {
        val minTop = 60f
        val maxTop = WORLD_H - GROUND_HEIGHT - pipeGap - 60f
        val topHeight = minTop + Random.nextFloat() * max(10f, maxTop - minTop)
        val bottomY = topHeight + pipeGap

        val coin = if (Random.nextFloat() < 0.38f) {
            CoinEntity(
                y = topHeight + pipeGap / 2f,
                collected = false,
                animTimer = Random.nextFloat() * PI.toFloat()
            )
        } else null

        pipes.add(
            PipePairEntity(
                x = WORLD_W + 20f,
                topHeight = topHeight,
                bottomY = bottomY,
                gap = pipeGap,
                coin = coin
            )
        )
    }

    private fun updateStageProgress() {
        val nextStage = stageLevelForScore(score)
        if (nextStage != stageLevel) {
            stageLevel = nextStage
            if (nextStage > highestStageInRun) highestStageInRun = nextStage
            stageBannerTimer = 2.8f
            onStageUpSfx()
            onHapticImpact(false)
            val stageColors = listOf(
                Color(0xFFFDE68A),
                Color(0xFFFB923C),
                Color(0xFF67E8F9),
                Color(0xFFC4B5FD),
                Color(0xFFF0ABFC),
                Color.White
            )
            spawnLightBurst(
                WORLD_W * 0.52f,
                WORLD_H * 0.36f,
                stageColors[(nextStage - 1).coerceIn(0, stageColors.lastIndex)],
                34
            )
        }
    }

    private fun updateWeather(dt: Float) {
        if (phase == GamePhase.PAUSED) return
        stageBannerTimer = max(0f, stageBannerTimer - dt)
        lightningFlash = max(0f, lightningFlash - dt * 2.8f)
        lightningTimer -= dt

        if (stageLevel == 3 && lightningTimer <= 0f) {
            lightningFlash = 0.85f
            screenShake = max(screenShake, 0.12f)
            lightningTimer = 4f + Random.nextFloat() * 6f
            repeat(18) {
                weatherParticles.add(
                    WeatherParticle(
                        x = Random.nextFloat() * WORLD_W,
                        y = -10f - Random.nextFloat() * 100f,
                        vx = -18f - Random.nextFloat() * 30f,
                        vy = 180f + Random.nextFloat() * 170f,
                        size = 1.5f + Random.nextFloat() * 2f,
                        life = 2.2f
                    )
                )
            }
        }

        val targetCount = when {
            stageLevel == 3 -> 70
            stageLevel >= 4 -> 34
            else -> 12
        }
        while (weatherParticles.size < targetCount) {
            val snow = stageLevel >= 4
            weatherParticles.add(
                WeatherParticle(
                    x = Random.nextFloat() * WORLD_W,
                    y = Random.nextFloat() * WORLD_H,
                    vx = if (snow) -10f + Random.nextFloat() * 20f else -8f - Random.nextFloat() * 10f,
                    vy = if (snow) 12f + Random.nextFloat() * 28f else 22f + Random.nextFloat() * 35f,
                    size = if (snow) 1.2f + Random.nextFloat() * 2.5f else 1f + Random.nextFloat() * 1.4f,
                    life = 3f + Random.nextFloat() * 4f
                )
            )
        }

        val wIter = weatherParticles.listIterator()
        while (wIter.hasNext()) {
            val wp = wIter.next()
            wp.x += wp.vx * dt
            wp.y += wp.vy * dt
            wp.life -= dt
            if (wp.y > WORLD_H + 12f || wp.life <= 0f || wp.x < -15f) {
                wIter.remove()
            }
        }
    }

    private fun spawnLightBurst(x: Float, y: Float, color: Color, count: Int) {
        repeat(count) {
            val angle = Random.nextFloat() * 2f * PI.toFloat()
            val speed = 55f + Random.nextFloat() * 230f
            val life = 0.7f + Random.nextFloat() * 0.8f
            particles.add(
                ParticleEntity(
                    x = x,
                    y = y,
                    vx = cos(angle) * speed,
                    vy = sin(angle) * speed,
                    size = 2f + Random.nextFloat() * 5f,
                    color = if (Random.nextFloat() > 0.25f) color else Color.White,
                    life = life,
                    maxLife = life
                )
            )
        }
    }

    private fun killBird() {
        if (!birdAlive) return
        birdAlive = false
        screenShake = 0.32f
        onHitSfx()
        onHapticImpact(true)

        repeat(14) {
            particles.add(
                ParticleEntity(
                    x = birdX,
                    y = birdY,
                    vx = (Random.nextFloat() - 0.5f) * 200f,
                    vy = (Random.nextFloat() - 0.5f) * 200f,
                    size = 4f + Random.nextFloat() * 4f,
                    color = if (Random.nextBoolean()) Color(0xFFF97316) else Color(0xFFEF4444),
                    life = 0.45f,
                    maxLife = 0.45f
                )
            )
        }

        val isNewBest = score > bestScoreKnown && score > 0
        if (isNewBest) {
            screenShake = max(screenShake, 0.25f)
            spawnLightBurst(WORLD_W * 0.5f, WORLD_H * 0.34f, Color(0xFFFACC15), 95)
            spawnLightBurst(WORLD_W * 0.5f, WORLD_H * 0.34f, Color(0xFFC4B5FD), 55)
            onRecordCelebrationSfx()
        } else if (score >= 5) {
            onRecordCelebrationSfx()
        }

        phase = GamePhase.GAME_OVER
        onFlightFinished(score, highestStageInRun, sessionCoins, isNewBest)
    }

    private fun checkAABB(
        x1: Float, y1: Float, w1: Float, h1: Float,
        x2: Float, y2: Float, w2: Float, h2: Float
    ): Boolean {
        return x1 < x2 + w2 && x1 + w1 > x2 && y1 < y2 + h2 && y1 + h1 > y2
    }
}

private fun mutableStateOfPhase(initial: GamePhase) =
    androidx.compose.runtime.mutableStateOf(initial)
