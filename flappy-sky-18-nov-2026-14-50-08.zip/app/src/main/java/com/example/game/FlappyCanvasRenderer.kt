package com.example.game

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.lerp
import com.example.model.BirdSkin
import com.example.model.findBirdSkin
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

fun DrawScope.renderFlappyWorld(engine: FlappyGameEngine) {
    // Read frameTick so Compose tracks draw invalidations
    engine.frameTick

    val scaleFactor = min(size.width / WORLD_W, size.height / WORLD_H)
    val offsetX = (size.width - WORLD_W * scaleFactor) / 2f
    val offsetY = (size.height - WORLD_H * scaleFactor) / 2f

    // 1. Full-bleed sky & ground extension so tablets/tall phones have zero black bars
    val (topCol, btmCol, horizonCol) = computeSkyColors(engine.dayProgress, engine.stageLevel)
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(topCol, btmCol, horizonCol),
            startY = 0f,
            endY = size.height
        ),
        size = size
    )

    val worldGroundScreenY = offsetY + (WORLD_H - GROUND_HEIGHT) * scaleFactor
    if (worldGroundScreenY < size.height) {
        drawRect(
            brush = Brush.verticalGradient(
                colors = listOf(Color(0xFFE9DC9C), Color(0xFF9B8950)),
                startY = worldGroundScreenY,
                endY = size.height
            ),
            topLeft = Offset(0f, worldGroundScreenY),
            size = Size(size.width, size.height - worldGroundScreenY)
        )
    }

    // 2. Scaled 360x640 logical playfield
    val shakeX = if (engine.screenShake > 0f) (Random.nextFloat() - 0.5f) * engine.screenShake * 8f else 0f
    val shakeY = if (engine.screenShake > 0f) (Random.nextFloat() - 0.5f) * engine.screenShake * 8f else 0f

    translate(left = offsetX, top = offsetY) {
        scale(scaleX = scaleFactor, scaleY = scaleFactor, pivot = Offset.Zero) {
            translate(left = shakeX, top = shakeY) {
                drawSkyDetails(engine, topCol, btmCol, horizonCol)
                drawParallax(engine)
                drawPipesAndCoins(engine)
                drawParticles(engine)
                drawBird(engine)
                drawGround(engine)
                drawWeatherEffects(engine)

                // Subtle atmospheric vignette
                drawRect(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.Transparent,
                            if (engine.dayProgress > 0.55f) Color(0x4D020617) else Color(0x2107233C)
                        ),
                        center = Offset(WORLD_W * 0.5f, WORLD_H * 0.45f),
                        radius = 430f
                    ),
                    topLeft = Offset(-80f, -80f),
                    size = Size(WORLD_W + 160f, WORLD_H + 160f)
                )
            }
        }
    }
}

private fun computeSkyColors(dayProgress: Float, stageLevel: Int): Triple<Color, Color, Color> {
    val dayTop = Color(0xFF37A4CA)
    val dayBtm = Color(0xFFB1EBF4)
    val nightTop = Color(0xFF080D26)
    val nightBtm = Color(0xFF262A67)

    var topCol = lerp(dayTop, nightTop, dayProgress)
    var btmCol = lerp(dayBtm, nightBtm, dayProgress)

    val stageTarget = when (stageLevel) {
        2 -> Color(0xFF713F55) to Color(0xFFF0A66B)
        3 -> Color(0xFF111C39) to Color(0xFF344B70)
        4 -> Color(0xFF102C4B) to Color(0xFF326C83)
        5 -> Color(0xFF160E3C) to Color(0xFF5A347E)
        6 -> Color(0xFF090D27) to Color(0xFF283E79)
        else -> null
    }
    if (stageTarget != null) {
        val mix = if (stageLevel == 2) 0.58f else 0.72f
        topCol = lerp(topCol, stageTarget.first, mix)
        btmCol = lerp(btmCol, stageTarget.second, mix)
    }

    val horizon = if (dayProgress > 0.55f || stageLevel >= 3) Color(0xFF27345F) else Color(0xFFB8EDF0)
    return Triple(topCol, btmCol, horizon)
}

private fun DrawScope.drawSkyDetails(
    engine: FlappyGameEngine,
    topCol: Color,
    btmCol: Color,
    horizonCol: Color
) {
    val p = engine.dayProgress

    // Playfield sky gradient
    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(topCol, btmCol, horizonCol),
            startY = 0f,
            endY = WORLD_H - GROUND_HEIGHT
        ),
        topLeft = Offset(-120f, -120f),
        size = Size(WORLD_W + 240f, WORLD_H - GROUND_HEIGHT + 120f)
    )

    // Horizon bloom
    drawRect(
        brush = Brush.radialGradient(
            colors = listOf(
                if (p > 0.55f || engine.stageLevel >= 3) Color(0x337767FF) else Color(0x57FFF5BE),
                Color.Transparent
            ),
            center = Offset(250f, 330f),
            radius = 260f
        ),
        topLeft = Offset(-60f, 80f),
        size = Size(WORLD_W + 120f, 360f)
    )

    // Twinkling stars
    val starVisibility = if (engine.stageLevel >= 3) {
        max(0.55f, ((p - 0.15f) / 0.55f).coerceIn(0f, 1f))
    } else {
        ((p - 0.28f) / 0.55f).coerceIn(0f, 1f)
    }
    if (starVisibility > 0.01f) {
        for (i in 0 until 34) {
            val x = ((i * 73 + 19) % WORLD_W.toInt()).toFloat()
            val y = 22f + ((i * 47 + 13) % 270).toFloat()
            val twinkle = 0.35f + 0.55f * (0.5f + 0.5f * sin(engine.visualTime * 2.2f + i))
            val alpha = (starVisibility * twinkle).coerceIn(0f, 1f)
            val starColor = (if (i % 5 == 0) Color(0xFFC4B5FD) else Color.White).copy(alpha = alpha)
            val sz = if (i % 4 == 0) 3.2f else 2.1f
            drawCircle(
                color = starColor.copy(alpha = alpha * 0.35f),
                radius = sz * 2.2f,
                center = Offset(x, y)
            )
            drawRect(
                color = starColor,
                topLeft = Offset(x - sz / 2f, y - sz / 2f),
                size = Size(sz, sz)
            )
        }
    }

    // Sun or Crescent Moon
    val sunX = 280f
    val sunY = 78f
    if (p < 0.72f) {
        val sunAlpha = (1f - p * 0.8f).coerceIn(0f, 1f)
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    Color(0xFFFFF1A6).copy(alpha = 0.55f * sunAlpha),
                    Color.Transparent
                ),
                center = Offset(sunX, sunY),
                radius = 44f
            ),
            radius = 44f,
            center = Offset(sunX, sunY)
        )
        drawCircle(
            color = Color(0xFFFFF3B0).copy(alpha = sunAlpha),
            radius = 21f,
            center = Offset(sunX, sunY)
        )
        drawCircle(
            color = Color.White.copy(alpha = 0.42f * sunAlpha),
            radius = 6f,
            center = Offset(sunX - 7f, sunY - 7f)
        )
    } else {
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(Color(0x66C4B5FD), Color.Transparent),
                center = Offset(sunX, sunY),
                radius = 38f
            ),
            radius = 38f,
            center = Offset(sunX, sunY)
        )
        drawCircle(
            color = Color(0xFFF8FAFC),
            radius = 18f,
            center = Offset(sunX, sunY)
        )
        drawCircle(
            color = topCol,
            radius = 15f,
            center = Offset(sunX - 7f, sunY - 5f)
        )
    }

    if (engine.stageLevel == 3) {
        drawRect(
            color = Color(0x330C132B),
            topLeft = Offset(-120f, -120f),
            size = Size(WORLD_W + 240f, WORLD_H - GROUND_HEIGHT + 120f)
        )
    }

    // Aurora ribbons for Stages 4–6
    if (engine.stageLevel >= 4) {
        val auroraAlpha = (0.22f + 0.08f * sin(engine.visualTime * 1.4f)).coerceIn(0.1f, 0.38f)
        val wave1 = sin(engine.visualTime) * 18f
        val auroraPath1 = Path().apply {
            moveTo(-40f, 150f + wave1)
            cubicTo(90f, 80f, 190f, 210f, WORLD_W + 40f, 110f)
        }
        drawPath(
            path = auroraPath1,
            color = Color(0xFF67E8F9).copy(alpha = auroraAlpha * 0.45f),
            style = Stroke(width = 24f, cap = StrokeCap.Round)
        )
        drawPath(
            path = auroraPath1,
            color = Color(0xFF67E8F9).copy(alpha = auroraAlpha),
            style = Stroke(width = 11f, cap = StrokeCap.Round)
        )

        val wave2 = cos(engine.visualTime * 0.8f) * 16f
        val auroraPath2 = Path().apply {
            moveTo(-30f, 205f + wave2)
            cubicTo(110f, 130f, 230f, 260f, WORLD_W + 60f, 155f)
        }
        drawPath(
            path = auroraPath2,
            color = Color(0xFFC084FC).copy(alpha = auroraAlpha * 0.45f),
            style = Stroke(width = 24f, cap = StrokeCap.Round)
        )
        drawPath(
            path = auroraPath2,
            color = Color(0xFFC084FC).copy(alpha = auroraAlpha),
            style = Stroke(width = 11f, cap = StrokeCap.Round)
        )
    }
}

private fun DrawScope.drawParallax(engine: FlappyGameEngine) {
    val night = engine.dayProgress > 0.58f
    val hillTint = when {
        engine.stageLevel == 3 -> Color(0xFF263653)
        engine.stageLevel >= 4 -> Color(0xFF243A68)
        night -> Color(0xFF17264F)
        else -> Color(0xFF3B9B78)
    }
    val backHillColor = if (night || engine.stageLevel >= 3) {
        Color(0xB8121D44)
    } else {
        Color(0x7A44A697)
    }

    engine.distantHills.forEach { h ->
        val rBack = h.r * 1.08f
        drawArc(
            color = backHillColor,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = Offset(h.x - rBack, h.y + 12f - rBack),
            size = Size(rBack * 2f, rBack * 2f)
        )
    }
    engine.distantHills.forEach { h ->
        drawArc(
            color = hillTint,
            startAngle = 180f,
            sweepAngle = 180f,
            useCenter = true,
            topLeft = Offset(h.x - h.r, h.y - h.r),
            size = Size(h.r * 2f, h.r * 2f)
        )
    }

    val cloudColor = if (night || engine.stageLevel >= 3) {
        Color(0xFFD8DDFF).copy(alpha = 0.22f)
    } else {
        Color.White.copy(alpha = 0.68f)
    }
    engine.clouds.forEach { cl ->
        drawRoundRect(
            color = cloudColor,
            topLeft = Offset(cl.x, cl.y + cl.h * 0.35f),
            size = Size(cl.w, cl.h * 0.65f),
            cornerRadius = CornerRadius(8f, 8f)
        )
        drawRoundRect(
            color = cloudColor,
            topLeft = Offset(cl.x + cl.w * 0.15f, cl.y + cl.h * 0.1f),
            size = Size(cl.w * 0.45f, cl.h * 0.8f),
            cornerRadius = CornerRadius(12f, 12f)
        )
        drawRoundRect(
            color = cloudColor,
            topLeft = Offset(cl.x + cl.w * 0.45f, cl.y),
            size = Size(cl.w * 0.4f, cl.h * 0.9f),
            cornerRadius = CornerRadius(14f, 14f)
        )
    }
}

private fun DrawScope.drawPipesAndCoins(engine: FlappyGameEngine) {
    engine.pipes.forEach { p ->
        drawSinglePipe(p.x, 0f, p.w, p.topHeight, isTop = true, night = engine.dayProgress > 0.55f)
        drawSinglePipe(
            p.x,
            p.bottomY,
            p.w,
            WORLD_H - GROUND_HEIGHT - p.bottomY,
            isTop = false,
            night = engine.dayProgress > 0.55f
        )

        val coin = p.coin
        if (coin != null && !coin.collected) {
            val coinX = p.x + p.w / 2f
            val coinY = coin.y + sin(coin.animTimer) * 4f
            val pulse = 1f + sin(engine.visualTime * 7f + coin.animTimer) * 0.08f

            translate(left = coinX, top = coinY) {
                scale(scaleX = pulse, scaleY = pulse, pivot = Offset.Zero) {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(Color(0x70FACC15), Color.Transparent),
                            center = Offset.Zero,
                            radius = 22f
                        ),
                        radius = 22f,
                        center = Offset.Zero
                    )
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFFFF7B2),
                                Color(0xFFFACC15),
                                Color(0xFFB45309)
                            ),
                            center = Offset(-3f, -4f),
                            radius = 13f
                        ),
                        radius = 10f,
                        center = Offset.Zero
                    )
                    drawCircle(
                        color = Color(0xFFFFF1A6),
                        radius = 10f,
                        center = Offset.Zero,
                        style = Stroke(width = 1.6f)
                    )
                    rotate(degrees = (engine.visualTime * 2.5f) * (180f / PI.toFloat()), pivot = Offset.Zero) {
                        drawRect(
                            color = Color.White.copy(alpha = 0.85f),
                            topLeft = Offset(-2f, -7f),
                            size = Size(3f, 5f)
                        )
                    }
                }
            }
        }
    }
}

private fun DrawScope.drawSinglePipe(
    x: Float,
    y: Float,
    w: Float,
    h: Float,
    isTop: Boolean,
    night: Boolean
) {
    if (h <= 0f) return
    val capHeight = 24f
    val capOverhang = 5f
    val capY = if (isTop) y + h - capHeight else y
    val capX = x - capOverhang
    val capW = w + capOverhang * 2f

    val glowColor = if (night) Color(0x474ADEFF) else Color(0x3822C55E)
    drawRect(
        color = glowColor,
        topLeft = Offset(x - 3f, y),
        size = Size(w + 6f, h)
    )

    drawRect(
        brush = Brush.horizontalGradient(
            0f to Color(0xFF087F4B),
            0.22f to Color(0xFF4ADE80),
            0.48f to Color(0xFF22C55E),
            0.78f to Color(0xFF16A34A),
            1f to Color(0xFF075B39),
            startX = x,
            endX = x + w
        ),
        topLeft = Offset(x, y),
        size = Size(w, h)
    )

    if (h > 6f) {
        drawRect(
            color = Color(0x85DCFFE6),
            topLeft = Offset(x + 5f, y + 2f),
            size = Size(5f, max(0f, h - 4f))
        )
        drawRect(
            color = Color(0x5C034B2B),
            topLeft = Offset(x + w - 11f, y + 2f),
            size = Size(7f, max(0f, h - 4f))
        )
    }
    drawRect(
        color = Color(0xFF064E3B),
        topLeft = Offset(x, y),
        size = Size(w, h),
        style = Stroke(width = 3f)
    )

    drawRect(
        brush = Brush.horizontalGradient(
            0f to Color(0xFF087F4B),
            0.20f to Color(0xFF86EFAC),
            0.50f to Color(0xFF22C55E),
            0.82f to Color(0xFF16A34A),
            1f to Color(0xFF064E3B),
            startX = capX,
            endX = capX + capW
        ),
        topLeft = Offset(capX, capY),
        size = Size(capW, capHeight)
    )
    drawRect(
        color = Color(0x6BFFFFFF),
        topLeft = Offset(capX + 5f, capY + 3f),
        size = Size(5f, capHeight - 6f)
    )
    drawRect(
        color = Color(0xFF064E3B),
        topLeft = Offset(capX, capY),
        size = Size(capW, capHeight),
        style = Stroke(width = 3f)
    )
    drawLine(
        color = Color(0x94DCFFE7),
        start = Offset(capX + 3f, capY + 3f),
        end = Offset(capX + capW - 3f, capY + 3f),
        strokeWidth = 1.2f
    )
}

private fun DrawScope.drawBird(engine: FlappyGameEngine) {
    val skin = findBirdSkin(engine.currentSkinId)
    val stage = engine.stageLevel

    translate(left = engine.birdX, top = engine.birdY) {
        rotate(degrees = engine.birdRotation * (180f / PI.toFloat()), pivot = Offset.Zero) {
            val auraColor = when {
                stage >= 5 -> Color(0xFFC084FC)
                stage >= 3 -> Color(0xFF67E8F9)
                else -> skin.bodyColor
            }
            val auraRadius = if (stage >= 4) 34f else 26f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(auraColor.copy(alpha = 0.36f), Color.Transparent),
                    center = Offset.Zero,
                    radius = auraRadius
                ),
                radius = auraRadius,
                center = Offset.Zero
            )

            // Energy trail ribbon for Stage 3+
            if (stage >= 3) {
                val trailAlpha = (0.24f + 0.14f * sin(engine.visualTime * 10f)).coerceIn(0.1f, 0.5f)
                val trailColor = if (stage >= 5) Color(0xFFC084FC) else Color(0xFF67E8F9)
                val trailPath = Path().apply {
                    moveTo(-15f, -3f)
                    quadraticTo(-31f - stage * 2f, 0f, -42f - stage * 3f, 7f)
                }
                drawPath(
                    path = trailPath,
                    color = trailColor.copy(alpha = trailAlpha * 0.45f),
                    style = Stroke(width = if (stage >= 5) 9f else 6f, cap = StrokeCap.Round)
                )
                drawPath(
                    path = trailPath,
                    color = trailColor.copy(alpha = trailAlpha),
                    style = Stroke(width = if (stage >= 5) 4f else 2.5f, cap = StrokeCap.Round)
                )
            }

            drawBirdGraphic(
                cx = 0f,
                cy = 0f,
                skin = skin,
                wingPhase = engine.birdWingPhase,
                scaleMod = 1f,
                stage = stage,
                time = engine.visualTime
            )
        }
    }
}

fun DrawScope.drawBirdGraphic(
    cx: Float,
    cy: Float,
    skin: BirdSkin,
    wingPhase: Float,
    scaleMod: Float = 1f,
    stage: Int = 1,
    time: Float = 0f
) {
    val outline = Color(0xFF0F172A)

    translate(left = cx, top = cy) {
        scale(scaleX = scaleMod, scaleY = scaleMod, pivot = Offset.Zero) {
            // 1. Body glow + gradient fill
            drawRoundRect(
                color = skin.bodyColor.copy(alpha = 0.25f),
                topLeft = Offset(-19f, -15f),
                size = Size(38f, 30f),
                cornerRadius = CornerRadius(12f, 12f)
            )
            val bodyPath = Path().apply {
                addRoundRect(
                    RoundRect(
                        rect = Rect(-16f, -12f, 16f, 12f),
                        cornerRadius = CornerRadius(10f, 10f)
                    )
                )
            }
            drawPath(
                path = bodyPath,
                brush = Brush.linearGradient(
                    0f to Color.White,
                    0.22f to skin.bodyColor,
                    1f to skin.wingColor,
                    start = Offset(-12f, -13f),
                    end = Offset(13f, 13f)
                )
            )
            drawPath(
                path = bodyPath,
                color = outline,
                style = Stroke(width = 2.5f)
            )

            // 2. Belly highlight
            drawCircle(
                color = Color.White.copy(alpha = 0.45f),
                radius = 7f,
                center = Offset(-4f, 2f)
            )

            // 3. Eye & pupil
            drawCircle(
                color = Color.White,
                radius = 5.5f,
                center = Offset(7f, -5f)
            )
            drawCircle(
                color = outline,
                radius = 5.5f,
                center = Offset(7f, -5f),
                style = Stroke(width = 1.5f)
            )
            drawCircle(
                color = skin.eyeColor,
                radius = 2.5f,
                center = Offset(9f, -5f)
            )

            // 4. Beak
            val beakPath = Path().apply {
                moveTo(13f, -3f)
                lineTo(21f, 1f)
                lineTo(13f, 5f)
                close()
            }
            drawPath(path = beakPath, color = skin.beakColor)
            drawPath(path = beakPath, color = outline, style = Stroke(width = 1.5f))

            // 5. Evolving multi-layer wings
            val flap = sin(wingPhase)
            val wingOffset = flap * (if (stage >= 3) 8f else 6f)
            val wingColors = when {
                stage >= 5 -> listOf(
                    Color(0xFFE9D5FF),
                    Color(0xFFC084FC),
                    Color(0xFF818CF8),
                    Color(0xFF67E8F9)
                )
                stage >= 3 -> listOf(
                    Color(0xFFECFEFF),
                    Color(0xFF67E8F9),
                    Color(0xFF38BDF8),
                    Color(0xFF0EA5E9)
                )
                stage >= 2 -> listOf(
                    Color(0xFFFFF7ED),
                    Color(0xFFFDBA74),
                    Color(0xFFFB923C),
                    skin.wingColor
                )
                else -> listOf(
                    Color.White.copy(alpha = 0.95f),
                    skin.wingColor,
                    skin.wingColor,
                    skin.wingColor
                )
            }

            if (stage >= 3) {
                val aura = if (stage >= 5) Color(0xFFC084FC) else Color(0xFF67E8F9)
                drawCircle(
                    color = aura.copy(alpha = 0.25f),
                    radius = 14f + stage * 1.6f,
                    center = Offset(-6f, -4f + wingOffset * 0.4f)
                )
            }

            val wingMembrane = Path().apply {
                moveTo(-13f, -3f + wingOffset * 0.45f)
                quadraticTo(-18f, -17f - max(0f, flap) * 4f, -7f, -13f - stage * 1.2f)
                quadraticTo(2f, -9f, 1f, 1f + wingOffset * 0.35f)
                quadraticTo(-5f, 7f, -13f, 5f + wingOffset)
                close()
            }
            drawPath(path = wingMembrane, color = wingColors[1])
            drawPath(path = wingMembrane, color = outline, style = Stroke(width = 1.4f))

            val featherCount = when {
                stage >= 6 -> 5
                stage >= 4 -> 4
                stage >= 2 -> 3
                else -> 1
            }
            for (feather in 0 until featherCount) {
                val spread = feather.toFloat() / max(1, featherCount - 1)
                val fx = -11f + spread * 12f
                val fy = -4f + wingOffset * 0.55f - spread * (5f + stage * 1.15f)
                val featherPath = Path().apply {
                    moveTo(fx, fy + 3f)
                    quadraticTo(
                        fx - 4f - stage * 0.35f,
                        fy - 5f - stage * 0.9f,
                        fx + 2f,
                        fy - 10f - stage * 1.15f
                    )
                    quadraticTo(fx + 5f, fy - 3f, fx + 3f, fy + 4f)
                    close()
                }
                drawPath(path = featherPath, color = wingColors[min(3, feather)])
                drawPath(
                    path = featherPath,
                    color = Color(0x8C0F172A),
                    style = Stroke(width = 0.8f)
                )
            }

            if (stage >= 4) {
                val arcAlpha = (0.7f + 0.25f * sin(time * 8f)).coerceIn(0.3f, 0.95f)
                val arcColor = (if (stage >= 5) Color(0xFFF5D0FE) else Color(0xFFCFFAFE))
                    .copy(alpha = arcAlpha)
                val arcPath = Path().apply {
                    moveTo(-12f, -7f)
                    quadraticTo(-5f, -19f - stage, 2f, -12f)
                }
                drawPath(
                    path = arcPath,
                    color = arcColor,
                    style = Stroke(width = 1.5f, cap = StrokeCap.Round)
                )
            }
        }
    }
}

private fun DrawScope.drawWeatherEffects(engine: FlappyGameEngine) {
    if (engine.stageLevel == 3) {
        engine.weatherParticles.forEach { p ->
            drawLine(
                color = Color(0x6BBEDCFF),
                start = Offset(p.x, p.y),
                end = Offset(p.x - 5f, p.y + 13f),
                strokeWidth = 1.4f
            )
        }
    } else if (engine.stageLevel >= 4) {
        engine.weatherParticles.forEachIndexed { idx, p ->
            val alpha = (0.28f + 0.45f * (0.5f + 0.5f * sin(engine.visualTime * 2f + idx)))
                .coerceIn(0.1f, 0.85f)
            val color = if (engine.stageLevel >= 5) Color(0xFFE9D5FF) else Color(0xFFDBEAFE)
            drawCircle(
                color = color.copy(alpha = alpha * 0.35f),
                radius = p.size * 2.2f,
                center = Offset(p.x, p.y)
            )
            drawCircle(
                color = color.copy(alpha = alpha),
                radius = p.size,
                center = Offset(p.x, p.y)
            )
        }
    }

    if (engine.lightningFlash > 0f) {
        val flash = engine.lightningFlash.coerceIn(0f, 1f)
        drawRect(
            color = Color(0xFFEAF6FF).copy(alpha = flash * 0.48f),
            topLeft = Offset(-80f, -80f),
            size = Size(WORLD_W + 160f, WORLD_H + 160f)
        )
        val bolt = Path().apply {
            moveTo(312f, 0f)
            lineTo(286f, 76f)
            lineTo(302f, 76f)
            lineTo(264f, 155f)
            lineTo(278f, 91f)
            lineTo(263f, 91f)
            close()
        }
        drawPath(
            path = bolt,
            color = Color(0xFF93C5FD).copy(alpha = flash * 0.45f),
            style = Stroke(width = 10f)
        )
        drawPath(
            path = bolt,
            color = Color(0xFFF8FBFF).copy(alpha = flash),
            style = Stroke(width = 4f)
        )
    }
}

private fun DrawScope.drawGround(engine: FlappyGameEngine) {
    val groundY = WORLD_H - GROUND_HEIGHT

    drawRect(
        brush = Brush.verticalGradient(
            colors = listOf(Color(0xFFE9DC9C), Color(0xFF9B8950)),
            startY = groundY,
            endY = WORLD_H
        ),
        topLeft = Offset(-80f, groundY),
        size = Size(WORLD_W + 160f, GROUND_HEIGHT + 80f)
    )

    // Top luminous grass strip
    drawRect(
        color = Color(0x38B7FF70),
        topLeft = Offset(-80f, groundY - 4f),
        size = Size(WORLD_W + 160f, 22f)
    )
    drawRect(
        color = Color(0xFF78D64B),
        topLeft = Offset(-80f, groundY),
        size = Size(WORLD_W + 160f, 16f)
    )
    drawRect(
        color = Color(0xFF558022),
        topLeft = Offset(-80f, groundY + 16f),
        size = Size(WORLD_W + 160f, 4f)
    )

    drawLine(
        color = Color(0xFF0F172A),
        start = Offset(-80f, groundY),
        end = Offset(WORLD_W + 80f, groundY),
        strokeWidth = 3f
    )

    var gx = engine.groundX - 48f
    while (gx < WORLD_W + 64f) {
        val blade = Path().apply {
            moveTo(gx, groundY + 16f)
            lineTo(gx + 12f, groundY)
            lineTo(gx + 20f, groundY + 16f)
            close()
        }
        drawPath(path = blade, color = Color(0xFF558022))
        gx += 24f
    }

    var dx = ((engine.groundX * 1.5f) % 36f) - 36f
    while (dx < WORLD_W + 72f) {
        drawRect(
            color = Color(0xFFC8BE70),
            topLeft = Offset(dx + 5f, groundY + 36f),
            size = Size(12f, 6f)
        )
        drawRect(
            color = Color(0xFFC8BE70),
            topLeft = Offset(dx + 22f, groundY + 54f),
            size = Size(8f, 4f)
        )
        dx += 36f
    }
}

private fun DrawScope.drawParticles(engine: FlappyGameEngine) {
    engine.particles.forEach { p ->
        val alpha = (p.life / p.maxLife).coerceIn(0f, 1f)
        val r = max(1.2f, p.size * 0.58f)
        drawCircle(
            color = p.color.copy(alpha = alpha * 0.35f),
            radius = r * 2.1f,
            center = Offset(p.x, p.y)
        )
        drawCircle(
            color = p.color.copy(alpha = alpha),
            radius = r,
            center = Offset(p.x, p.y)
        )
        drawCircle(
            color = Color.White.copy(alpha = alpha * 0.72f),
            radius = max(0.7f, p.size * 0.18f),
            center = Offset(p.x - p.size * 0.18f, p.y - p.size * 0.18f)
        )
    }
}
