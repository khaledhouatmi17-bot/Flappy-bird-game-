package com.example.model

import androidx.compose.ui.graphics.Color

enum class GamePhase {
    MENU,
    READY,
    PLAYING,
    PAUSED,
    GAME_OVER
}

enum class MedalTier(val label: String, val symbol: String, val color: Color) {
    NONE("NONE", "—", Color(0xFF475569)),
    BRONZE("BRONZE", "▲", Color(0xFFD97706)),
    SILVER("SILVER", "●", Color(0xFF94A3B8)),
    GOLD("GOLD", "★", Color(0xFFEAB308)),
    PLATINUM("PLATINUM", "♦", Color(0xFF06B6D4));

    companion object {
        fun fromScore(score: Int): MedalTier = when {
            score >= 40 -> PLATINUM
            score >= 25 -> GOLD
            score >= 10 -> SILVER
            score >= 5 -> BRONZE
            else -> NONE
        }
    }
}

data class BirdSkin(
    val id: String,
    val name: String,
    val shortName: String,
    val bodyColor: Color,
    val wingColor: Color,
    val beakColor: Color,
    val eyeColor: Color,
    val unlockCost: Int
)

val BIRD_SKINS: List<BirdSkin> = listOf(
    BirdSkin(
        id = "classic",
        name = "PIXEL CHICK",
        shortName = "PIXEL",
        bodyColor = Color(0xFFFBBF24),
        wingColor = Color(0xFFF59E0B),
        beakColor = Color(0xFFF97316),
        eyeColor = Color(0xFF0F172A),
        unlockCost = 0
    ),
    BirdSkin(
        id = "crimson",
        name = "RED PHOENIX",
        shortName = "PHOENIX",
        bodyColor = Color(0xFFEF4444),
        wingColor = Color(0xFFB91C1C),
        beakColor = Color(0xFFFACC15),
        eyeColor = Color(0xFFFFFFFF),
        unlockCost = 5
    ),
    BirdSkin(
        id = "cyber",
        name = "CYBER ROBOT",
        shortName = "CYBER",
        bodyColor = Color(0xFF06B6D4),
        wingColor = Color(0xFF0284C7),
        beakColor = Color(0xFFF43F5E),
        eyeColor = Color(0xFF22C55E),
        unlockCost = 15
    ),
    BirdSkin(
        id = "midnight",
        name = "NIGHT OWL",
        shortName = "OWL",
        bodyColor = Color(0xFF6366F1),
        wingColor = Color(0xFF4338CA),
        beakColor = Color(0xFFF59E0B),
        eyeColor = Color(0xFFFEF08A),
        unlockCost = 25
    ),
    BirdSkin(
        id = "emerald",
        name = "FOREST PARROT",
        shortName = "PARROT",
        bodyColor = Color(0xFF22C55E),
        wingColor = Color(0xFF15803D),
        beakColor = Color(0xFFEA580C),
        eyeColor = Color(0xFF0F172A),
        unlockCost = 40
    ),
    BirdSkin(
        id = "golden",
        name = "ROYAL KING",
        shortName = "ROYAL",
        bodyColor = Color(0xFFEAB308),
        wingColor = Color(0xFFCA8A04),
        beakColor = Color(0xFFDC2626),
        eyeColor = Color(0xFF7C3AED),
        unlockCost = 60
    )
)

fun findBirdSkin(skinId: String): BirdSkin =
    BIRD_SKINS.firstOrNull { it.id == skinId } ?: BIRD_SKINS.first()

data class EvolutionStage(
    val level: Int,
    val name: String,
    val subtitle: String,
    val accentColor: Color
)

val EVOLUTION_STAGES: List<EvolutionStage> = listOf(
    EvolutionStage(1, "MEADOW FLIGHT", "WINGS AWAKEN", Color(0xFFFDE68A)),
    EvolutionStage(2, "SUNSET RIDGE", "EMBER FEATHERS", Color(0xFFFB923C)),
    EvolutionStage(3, "THUNDER SKIES", "STORM WINGS", Color(0xFF67E8F9)),
    EvolutionStage(4, "FROST AURORA", "FROST WINGS", Color(0xFFC4B5FD)),
    EvolutionStage(5, "NEBULA REALM", "COSMIC WINGS", Color(0xFFF0ABFC)),
    EvolutionStage(6, "CELESTIAL WINGS", "ASCENDED FORM", Color(0xFFFFFFFF))
)

fun stageForLevel(level: Int): EvolutionStage =
    EVOLUTION_STAGES[(level - 1).coerceIn(0, EVOLUTION_STAGES.lastIndex)]

fun stageLevelForScore(score: Int): Int = (score / 5 + 1).coerceIn(1, 6)

data class PlayerProfile(
    val bestScore: Int = 0,
    val highestStage: Int = 1,
    val totalCoins: Int = 0,
    val selectedSkin: String = "classic",
    val unlockedSkins: Set<String> = setOf("classic"),
    val soundEnabled: Boolean = true,
    val musicEnabled: Boolean = true,
    val dayNightCycle: Boolean = true,
    val diffProgression: Boolean = true
)

data class FlightRecord(
    val id: String,
    val score: Int,
    val stageReached: Int,
    val coinsEarned: Int,
    val skinId: String,
    val timestampMillis: Long
)
