package com.example.data

import android.content.Context
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.core.stringSetPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.example.model.BIRD_SKINS
import com.example.model.FlightRecord
import com.example.model.PlayerProfile
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.UUID

private val Context.playerDataStore by preferencesDataStore(name = "flappy_sky_local")

class PlayerRepository(context: Context) {
    private val dataStore = context.applicationContext.playerDataStore

    private object Keys {
        val BEST_SCORE = intPreferencesKey("best_score")
        val HIGHEST_STAGE = intPreferencesKey("highest_stage")
        val TOTAL_COINS = intPreferencesKey("total_coins")
        val SELECTED_SKIN = stringPreferencesKey("selected_skin")
        val UNLOCKED_SKINS = stringSetPreferencesKey("unlocked_skins")
        val SOUND_ENABLED = booleanPreferencesKey("sound_enabled")
        val MUSIC_ENABLED = booleanPreferencesKey("music_enabled")
        val DAY_NIGHT_CYCLE = booleanPreferencesKey("day_night_cycle")
        val DIFF_PROGRESSION = booleanPreferencesKey("diff_progression")
        val RECENT_FLIGHTS = stringPreferencesKey("recent_flights_json")
    }

    private val safePreferences: Flow<Preferences> = dataStore.data
        .catch { exception ->
            if (exception is IOException) {
                emit(emptyPreferences())
            } else {
                throw exception
            }
        }

    val profileFlow: Flow<PlayerProfile> = safePreferences.map { prefs ->
        val unlocked = (prefs[Keys.UNLOCKED_SKINS] ?: setOf("classic")) + "classic"
        val rawSelected = prefs[Keys.SELECTED_SKIN] ?: "classic"
        val selected = if (rawSelected in unlocked && BIRD_SKINS.any { it.id == rawSelected }) {
            rawSelected
        } else {
            "classic"
        }
        PlayerProfile(
            bestScore = (prefs[Keys.BEST_SCORE] ?: 0).coerceAtLeast(0),
            highestStage = (prefs[Keys.HIGHEST_STAGE] ?: 1).coerceIn(1, 6),
            totalCoins = (prefs[Keys.TOTAL_COINS] ?: 0).coerceAtLeast(0),
            selectedSkin = selected,
            unlockedSkins = unlocked,
            soundEnabled = prefs[Keys.SOUND_ENABLED] ?: true,
            musicEnabled = prefs[Keys.MUSIC_ENABLED] ?: true,
            dayNightCycle = prefs[Keys.DAY_NIGHT_CYCLE] ?: true,
            diffProgression = prefs[Keys.DIFF_PROGRESSION] ?: true
        )
    }

    val recentFlightsFlow: Flow<List<FlightRecord>> = safePreferences.map { prefs ->
        decodeFlights(prefs[Keys.RECENT_FLIGHTS])
    }

    suspend fun recordCompletedFlight(
        score: Int,
        stageReached: Int,
        coinsEarned: Int,
        skinId: String
    ): Result<Unit> = runCatching {
        val clampedScore = score.coerceIn(0, 1_000_000)
        val clampedStage = stageReached.coerceIn(1, 6)
        val clampedCoins = coinsEarned.coerceIn(0, 100_000)
        val validSkin = if (BIRD_SKINS.any { it.id == skinId }) skinId else "classic"

        dataStore.edit { prefs ->
            val prevBest = prefs[Keys.BEST_SCORE] ?: 0
            val prevStage = prefs[Keys.HIGHEST_STAGE] ?: 1
            val prevCoins = prefs[Keys.TOTAL_COINS] ?: 0

            prefs[Keys.BEST_SCORE] = maxOf(prevBest, clampedScore)
            prefs[Keys.HIGHEST_STAGE] = maxOf(prevStage, clampedStage).coerceIn(1, 6)
            prefs[Keys.TOTAL_COINS] = (prevCoins + clampedCoins).coerceAtMost(10_000_000)

            val existing = decodeFlights(prefs[Keys.RECENT_FLIGHTS])
            val newRecord = FlightRecord(
                id = UUID.randomUUID().toString(),
                score = clampedScore,
                stageReached = clampedStage,
                coinsEarned = clampedCoins,
                skinId = validSkin,
                timestampMillis = System.currentTimeMillis()
            )
            val updated = (listOf(newRecord) + existing).take(15)
            prefs[Keys.RECENT_FLIGHTS] = encodeFlights(updated)
        }
    }

    suspend fun unlockOrEquipSkin(skinId: String): Result<Boolean> = runCatching {
        val skin = BIRD_SKINS.firstOrNull { it.id == skinId }
            ?: throw IllegalArgumentException("Unknown skin: $skinId")

        var newlyUnlocked = false
        dataStore.edit { prefs ->
            val currentUnlocked = (prefs[Keys.UNLOCKED_SKINS] ?: setOf("classic")) + "classic"
            val currentCoins = prefs[Keys.TOTAL_COINS] ?: 0

            if (skin.id in currentUnlocked) {
                prefs[Keys.SELECTED_SKIN] = skin.id
            } else {
                if (currentCoins < skin.unlockCost) {
                    throw IllegalStateException("Need ${skin.unlockCost} coins to unlock ${skin.name}")
                }
                prefs[Keys.TOTAL_COINS] = (currentCoins - skin.unlockCost).coerceAtLeast(0)
                prefs[Keys.UNLOCKED_SKINS] = currentUnlocked + skin.id
                prefs[Keys.SELECTED_SKIN] = skin.id
                newlyUnlocked = true
            }
        }
        newlyUnlocked
    }

    suspend fun updateSettings(
        soundEnabled: Boolean,
        musicEnabled: Boolean,
        dayNightCycle: Boolean,
        diffProgression: Boolean
    ): Result<Unit> = runCatching {
        dataStore.edit { prefs ->
            prefs[Keys.SOUND_ENABLED] = soundEnabled
            prefs[Keys.MUSIC_ENABLED] = musicEnabled
            prefs[Keys.DAY_NIGHT_CYCLE] = dayNightCycle
            prefs[Keys.DIFF_PROGRESSION] = diffProgression
        }
    }

    private fun encodeFlights(flights: List<FlightRecord>): String {
        val array = JSONArray()
        flights.forEach { record ->
            array.put(
                JSONObject().apply {
                    put("id", record.id)
                    put("score", record.score)
                    put("stageReached", record.stageReached)
                    put("coinsEarned", record.coinsEarned)
                    put("skinId", record.skinId)
                    put("timestampMillis", record.timestampMillis)
                }
            )
        }
        return array.toString()
    }

    private fun decodeFlights(raw: String?): List<FlightRecord> {
        if (raw.isNullOrBlank()) return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val obj = array.optJSONObject(i) ?: continue
                    add(
                        FlightRecord(
                            id = obj.optString("id", i.toString()),
                            score = obj.optInt("score", 0).coerceAtLeast(0),
                            stageReached = obj.optInt("stageReached", 1).coerceIn(1, 6),
                            coinsEarned = obj.optInt("coinsEarned", 0).coerceAtLeast(0),
                            skinId = obj.optString("skinId", "classic"),
                            timestampMillis = obj.optLong("timestampMillis", 0L)
                        )
                    )
                }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }
}
